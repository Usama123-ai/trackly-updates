// updater-ui.js - "Update now" bar + "Check for updates" link on the dashboard.
(function () {
  const bar = document.getElementById("updateBar");
  const msg = document.getElementById("updateMsg");
  const btn = document.getElementById("updateBtn");
  const link = document.getElementById("checkUpdateLink");
  const result = document.getElementById("checkResult");
  const verNum = document.getElementById("verNum");
  const current = chrome.runtime.getManifest().version;
  if (verNum) verNum.textContent = current;

  function render(info) {
    if (tracklyUpdateAvailable(info, current)) {
      msg.textContent = "🔄 New version available: v" + info.version + (info.notes ? " — " + info.notes : "");
      bar.style.display = "flex";
    } else {
      bar.style.display = "none";
    }
  }

  chrome.storage.local.get({ updateInfo: null }, (d) => render(d.updateInfo));
  tracklyCheckForUpdate(true).then(render);
  chrome.storage.onChanged.addListener((c, ns) => { if (ns === "local" && c.updateInfo) render(c.updateInfo.newValue); });

  function friendly(e) {
    const m = e && e.message;
    if (e && e.name === "AbortError") return "No folder selected. Click Update now and choose the Trackly folder.";
    if (m === "WRONG_FOLDER") return "That is not the Trackly extension folder. Choose the folder that contains manifest.json.";
    if (m === "NO_UPDATE") return "Already on the latest version.";
    if (m === "HASH_MISMATCH") return "Download not ready yet (GitHub is still refreshing). Wait 5 minutes and try again.";
    if (m === "DOWNLOAD_FAILED") return "Could not download the update. Check your internet and try again.";
    if (m === "BAD_ZIP") return "The update file is not valid. Please tell the admin.";
    return "Update failed: " + (m || e);
  }

  btn.addEventListener("click", async () => {
    btn.disabled = true;
    try {
      await tracklyApplyUpdate((t) => { msg.textContent = t; });
    } catch (e) {
      msg.textContent = friendly(e);
      btn.disabled = false;
    }
  });

  link.addEventListener("click", async (ev) => {
    ev.preventDefault();
    result.textContent = "Checking...";
    const info = await tracklyCheckForUpdate(true);
    render(info);
    result.textContent = tracklyUpdateAvailable(info, current) ? "Update found!" : "You are up to date.";
    setTimeout(() => { result.textContent = ""; }, 4000);
  });
})();
