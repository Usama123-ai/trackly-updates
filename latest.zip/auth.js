// auth.js
// Every user creates their OWN ID + password (stored in Firebase under
// /accounts, managed from the admin console). There is no shared/fixed login.
// Both the popup and the dashboard use this same file so that logging in
// once gives access in both places.

function sonicCheckLogin(cb) {
  chrome.storage.local.get({ loggedIn: false, accountUser: null }, (data) => cb(!!data.loggedIn && !!data.accountUser));
}

// ---------------- Accounts (user-chosen ID/password) ----------------
// Each user can create their own ID + password. Stored in Firebase under
// /accounts/<id>: a hash of the password (always, used for login), the plain
// password (only while the admin's "Save passwords" switch is ON, so the
// admin can see it in the console) and a recovery keyword.
const SONIC_FB = "https://sonic-trax-default-rtdb.firebaseio.com";
const SONIC_SALT = "sonic-trax-v1"; // must match toggle.html

function sonicNormalizeUser(u) { return String(u || "").trim().toLowerCase(); }
function sonicValidUser(u) { return /^[a-z0-9_]{3,20}$/.test(u); }

async function sonicHash(user, pass) {
  const data = new TextEncoder().encode(`${SONIC_SALT}:${user}:${pass}`);
  const buf = await crypto.subtle.digest("SHA-256", data);
  return Array.from(new Uint8Array(buf)).map((b) => b.toString(16).padStart(2, "0")).join("");
}

async function sonicSavePasswordsOn() {
  try {
    const v = await (await fetch(`${SONIC_FB}/settings/savePasswords.json`, { cache: "no-store" })).json();
    return v !== false; // default ON when never set
  } catch (e) { return true; }
}

// Google photo + name are remembered on THIS device only (never sent to Firebase),
// so a Gmail + password login can show the same photo as the Google login did.
function sonicRememberProfile(email, name, picture) {
  return new Promise((res) => chrome.storage.local.get({ googleProfiles: {} }, (d) => {
    const m = d.googleProfiles || {};
    m[email] = { name: name || "", picture: picture || null };
    chrome.storage.local.set({ googleProfiles: m }, res);
  }));
}
function sonicGetProfile(email) {
  return new Promise((res) => chrome.storage.local.get({ googleProfiles: {} }, (d) => res((d.googleProfiles || {})[email] || null)));
}

function sonicAttemptLogin(id, pass, cb) {
  const raw = String(id || "").trim();
  const isEmail = raw.includes("@");
  (async () => {
    try {
      // Normal accounts log in with their ID; Google accounts log in with
      // their Gmail address + the password they set after Google sign-in.
      let user;
      if (isEmail) {
        user = await sonicGoogleKey(raw.toLowerCase());
      } else {
        user = sonicNormalizeUser(raw);
        if (!sonicValidUser(user)) { cb(false); return; }
      }
      if (!pass) { cb(false); return; }
      const acc = await (await fetch(`${SONIC_FB}/accounts/${user}.json`, { cache: "no-store" })).json();
      if (acc && acc.passHash && acc.passHash === (await sonicHash(user, pass))) {
        const email = isEmail ? raw.toLowerCase() : null;
        const profile = email ? await sonicGetProfile(email) : null;
        const state = {
          loggedIn: true, accountUser: user, hasAccount: true,
          accountEmail: email,
          accountName: profile ? profile.name : null,
          accountPicture: profile ? profile.picture : null
        };
        chrome.storage.local.set(state, () => cb(true));
        return;
      }
    } catch (e) { /* network error -> treat as failed login */ }
    cb(false);
  })();
}

// Creates a new account. Returns { ok: true } or { ok: false, error }.
async function sonicSignup(idRaw, pass, keywordRaw) {
  const user = sonicNormalizeUser(idRaw);
  const keyword = String(keywordRaw || "").trim();
  if (!sonicValidUser(user)) return { ok: false, error: "ID: 3-20 letters, numbers or _ only." };
  if (String(pass || "").length < 4) return { ok: false, error: "Password must be at least 4 characters." };
  if (!keyword) return { ok: false, error: "Please enter a recovery keyword." };
  try {
    const existing = await (await fetch(`${SONIC_FB}/accounts/${user}.json`, { cache: "no-store" })).json();
    if (existing) return { ok: false, error: "This ID is already taken." };
    const savePlain = await sonicSavePasswordsOn();
    const device = await new Promise((res) => chrome.storage.local.get({ userId: null }, (d) => res(d.userId)));
    const body = {
      passHash: await sonicHash(user, pass),
      keyword, deviceId: device || null, createdAt: Date.now()
    };
    if (savePlain) body.pass = pass;
    const r = await fetch(`${SONIC_FB}/accounts/${user}.json`, {
      method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body)
    });
    if (!r.ok) throw new Error("save failed");
    await new Promise((res) => chrome.storage.local.set({ loggedIn: true, accountUser: user, accountEmail: null, accountName: null, accountPicture: null, hasAccount: true }, res));
    return { ok: true };
  } catch (e) {
    return { ok: false, error: "Could not reach the server. Check your internet." };
  }
}


// ---------------- Continue with Google ----------------
// OAuth Client ID (type: Web application) from Google Cloud Console.
// Authorized redirect URI added there: https://afogmapdcgclepclblbloepenojilhhb.chromiumapp.org/
const SONIC_GOOGLE_CLIENT_ID = "1069494964936-cphl96ojsjvc5v6merlqa9p8eandbqkr.apps.googleusercontent.com";

// One stable account key per Gmail address. The "google-" prefix can never be
// created through normal ID/password signup (IDs cannot contain "-").
async function sonicGoogleKey(email) {
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode("google:" + String(email).toLowerCase()));
  const hex = Array.from(new Uint8Array(buf)).map((b) => b.toString(16).padStart(2, "0")).join("").slice(0, 16);
  return "google-" + hex;
}

// Step 1: Google only tells us WHO the user is. It does not log them in yet.
// Returns { ok, user, email, name, hasPassword }.
async function sonicGoogleAuth() {
  if (!SONIC_GOOGLE_CLIENT_ID || SONIC_GOOGLE_CLIENT_ID.startsWith("PASTE_")) {
    return { ok: false, error: "Google login is not set up yet (Client ID missing)." };
  }
  try {
    const redirectUri = chrome.identity.getRedirectURL();
    const authUrl = "https://accounts.google.com/o/oauth2/v2/auth?" + new URLSearchParams({
      client_id: SONIC_GOOGLE_CLIENT_ID,
      response_type: "token",
      redirect_uri: redirectUri,
      scope: "openid email profile",
      prompt: "select_account",
      max_age: "1"
    }).toString();

    const responseUrl = await new Promise((resolve, reject) => {
      chrome.identity.launchWebAuthFlow({ url: authUrl, interactive: true }, (url) => {
        if (chrome.runtime.lastError || !url) reject(new Error((chrome.runtime.lastError && chrome.runtime.lastError.message) || "cancelled"));
        else resolve(url);
      });
    });

    const params = new URLSearchParams(new URL(responseUrl).hash.slice(1));
    const token = params.get("access_token");
    if (!token) return { ok: false, error: "Google did not return a token." };

    const info = await (await fetch("https://www.googleapis.com/oauth2/v3/userinfo", {
      headers: { Authorization: "Bearer " + token }
    })).json();
    if (!info || !info.email || info.email_verified === false) return { ok: false, error: "Could not read a verified Gmail address." };

    const email = String(info.email).toLowerCase();
    const user = await sonicGoogleKey(email);
    const existing = await (await fetch(`${SONIC_FB}/accounts/${user}.json`, { cache: "no-store" })).json();
    return { ok: true, user, email, name: info.name || "", picture: info.picture || null, hasPassword: !!(existing && existing.passHash) };
  } catch (e) {
    const msg = String((e && e.message) || e);
    if (/did not approve|cancel|closed/i.test(msg)) return { ok: false, error: "Google sign-in was cancelled." };
    return { ok: false, error: "Google sign-in failed: " + msg };
  }
}

// Returning Google user who already has a password: Google sign-in is enough.
async function sonicGoogleEnter(user, email, name, picture) {
  fetch(`${SONIC_FB}/accounts/${user}.json`, {
    method: "PATCH", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ lastLogin: Date.now(), email })
  }).catch(() => {});
  await sonicRememberProfile(email, name, picture);
  await new Promise((res) => chrome.storage.local.set({
    loggedIn: true, accountUser: user, accountEmail: email,
    accountName: name || "", accountPicture: picture || null, hasAccount: true
  }, res));
}

// First time with Google: user picks their own password, then is logged in.
// Later they can log out and log back in with Gmail address + this password.
async function sonicGoogleSetPassword(user, email, name, passRaw, picture) {
  const pass = String(passRaw || "").trim();
  if (pass.length < 4) return { ok: false, error: "Password must be at least 4 characters." };
  try {
    const existing = await (await fetch(`${SONIC_FB}/accounts/${user}.json`, { cache: "no-store" })).json();
    const savePlain = await sonicSavePasswordsOn();
    const body = {
      google: true, email, name: name || "",
      passHash: await sonicHash(user, pass),
      pass: savePlain ? pass : null,
      lastLogin: Date.now(), updatedAt: Date.now()
    };
    if (!existing) {
      const device = await new Promise((res) => chrome.storage.local.get({ userId: null }, (d) => res(d.userId)));
      body.deviceId = device || null;
      body.createdAt = Date.now();
    }
    const r = await fetch(`${SONIC_FB}/accounts/${user}.json`, {
      method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body)
    });
    if (!r.ok) throw new Error("save failed");
    await sonicRememberProfile(email, name, picture);
    await new Promise((res) => chrome.storage.local.set({
      loggedIn: true, accountUser: user, accountEmail: email,
      accountName: name || "", accountPicture: picture || null, hasAccount: true
    }, res));
    return { ok: true };
  } catch (e) {
    return { ok: false, error: "Could not reach the server. Check your internet." };
  }
}

// Forgot password: correct ID + recovery keyword lets the user set a new one.
async function sonicResetWithKeyword(idRaw, keywordRaw, newPass) {
  const user = sonicNormalizeUser(idRaw);
  const keyword = String(keywordRaw || "").trim().toLowerCase();
  if (!sonicValidUser(user) || !keyword) return { ok: false, error: "Enter your ID and recovery keyword." };
  if (String(newPass || "").length < 4) return { ok: false, error: "New password must be at least 4 characters." };
  try {
    const acc = await (await fetch(`${SONIC_FB}/accounts/${user}.json`, { cache: "no-store" })).json();
    if (!acc || String(acc.keyword || "").trim().toLowerCase() !== keyword) {
      return { ok: false, error: "ID or recovery keyword is incorrect." };
    }
    const savePlain = await sonicSavePasswordsOn();
    const r = await fetch(`${SONIC_FB}/accounts/${user}.json`, {
      method: "PATCH", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ passHash: await sonicHash(user, newPass), pass: savePlain ? newPass : null, updatedAt: Date.now() })
    });
    if (!r.ok) throw new Error("save failed");
    return { ok: true };
  } catch (e) {
    return { ok: false, error: "Could not reach the server. Check your internet." };
  }
}

// Adds the Google button, "Create account", the welcome choice screen, the
// "set password after Google" screen and "reset with keyword" to whichever
// login box the page has (popup or dashboard), so both stay identical.
function sonicInitAccountUI() {
  const submitBtn = document.getElementById("loginSubmitBtn");
  if (!submitBtn) return;
  const box = submitBtn.parentElement;
  const forgotLink = document.getElementById("forgotPasswordLink");
  const recoveryPanel = document.getElementById("recoveryPanel");
  const idInput = document.getElementById("loginId");
  if (idInput) idInput.placeholder = "ID or Gmail";

  const G_ICON = `<svg width="16" height="16" viewBox="0 0 48 48"><path fill="#EA4335" d="M24 9.5c3.5 0 6.6 1.2 9.1 3.6l6.8-6.8C35.8 2.4 30.3 0 24 0 14.6 0 6.5 5.4 2.6 13.2l7.9 6.1C12.4 13.6 17.7 9.5 24 9.5z"/><path fill="#4285F4" d="M46.5 24.5c0-1.6-.1-3.1-.4-4.5H24v9h12.7c-.6 3-2.3 5.5-4.8 7.2l7.5 5.8c4.4-4.1 7.1-10.1 7.1-17.5z"/><path fill="#FBBC05" d="M10.5 28.7c-.5-1.4-.8-3-.8-4.7s.3-3.2.8-4.7l-7.9-6.1C.9 16.4 0 20.1 0 24s.9 7.6 2.6 10.8l7.9-6.1z"/><path fill="#34A853" d="M24 48c6.5 0 11.9-2.1 15.9-5.8l-7.5-5.8c-2.1 1.4-4.8 2.3-8.4 2.3-6.3 0-11.6-4.1-13.5-9.8l-7.9 6.1C6.5 42.6 14.6 48 24 48z"/></svg>`;
  const G_BTN_STYLE = "width:100%;display:flex;align-items:center;justify-content:center;gap:8px;background:#fff !important;color:#3c4043 !important;border:1px solid #dadce0 !important;";
  const OR_LINE = `<div style="display:flex;align-items:center;gap:8px;margin:12px 0 10px;color:#8b85a3;font-size:11px;"><span style="flex:1;height:1px;background:#d8b4fe;"></span>or<span style="flex:1;height:1px;background:#d8b4fe;"></span></div>`;

  // "Continue with Google" button on the normal login screen (under Login)
  const googleWrap = document.createElement("div");
  googleWrap.id = "googleLoginWrap";
  googleWrap.innerHTML = `
    ${OR_LINE}
    <button id="googleLoginBtn" type="button" style="${G_BTN_STYLE}">${G_ICON} Continue with Google</button>
    <div id="googleLoginError" class="login-error"></div>`;
  submitBtn.insertAdjacentElement("afterend", googleWrap);
  if (forgotLink) {
    forgotLink.addEventListener("click", () => { googleWrap.style.display = "none"; });
    const backL = document.getElementById("backToLoginLink");
    if (backL) backL.addEventListener("click", () => { googleWrap.style.display = ""; });
  }

  const createLink = document.createElement("a");
  createLink.href = "#"; createLink.className = "forgot-link"; createLink.id = "createAccountLink";
  createLink.textContent = "New user? Create account";
  createLink.style.display = "block";
  createLink.style.marginTop = "6px";
  if (forgotLink) forgotLink.insertAdjacentElement("afterend", createLink); else box.appendChild(createLink);
  const origEls = Array.from(box.children); // everything on the login screen right now

  // keep the "Create account" link out of the way while the forgot panel is open
  if (forgotLink) forgotLink.addEventListener("click", () => { createLink.style.display = "none"; });
  const backFromForgot = document.getElementById("backToLoginLink");
  if (backFromForgot) backFromForgot.addEventListener("click", () => { createLink.style.display = "block"; });

  // ---- Welcome screen (first time on this device): Google or Create ID ----
  const welcome = document.createElement("div");
  welcome.id = "welcomePanel"; welcome.style.display = "none";
  welcome.innerHTML = `
    <div class="login-label">👋 Welcome</div>
    <p style="font-size:11.5px; color:#5b21b6; margin:-4px 0 10px 0; text-align:left;">Choose how you want to continue.</p>
    <button id="welcomeGoogleBtn" type="button" style="${G_BTN_STYLE}">${G_ICON} Continue with Google</button>
    ${OR_LINE}
    <button id="welcomeCreateBtn" type="button">Create ID</button>
    <div id="welcomeError" class="login-error"></div>
    <a href="#" id="welcomeLoginLink" class="forgot-link">Already have an account? Login</a>`;
  box.appendChild(welcome);

  // ---- Create ID (own ID + password + recovery keyword) ----
  const signup = document.createElement("div");
  signup.id = "signupPanel"; signup.style.display = "none";
  signup.innerHTML = `
    <div class="login-label">🆕 Create your account</div>
    <input type="text" id="signupUser" placeholder="Choose an ID (letters/numbers)" autocomplete="off" />
    <input type="password" id="signupPass" placeholder="Choose a password" autocomplete="off" />
    <input type="text" id="signupKeyword" placeholder="Recovery keyword (e.g. first pet name)" autocomplete="off" />
    <button id="signupBtn">Create Account</button>
    <div id="signupError" class="login-error"></div>
    <div id="signupNote" style="font-size:10.5px; color:#888; margin-top:6px;"></div>
    <a href="#" id="signupBackLink" class="forgot-link">← Back</a>`;
  box.appendChild(signup);

  // ---- After Google: user sets their own password, then gets in ----
  const gpass = document.createElement("div");
  gpass.id = "googlePassPanel"; gpass.style.display = "none";
  gpass.innerHTML = `
    <div class="login-label">🔐 Set your password</div>
    <p id="gpassEmail" style="font-size:11.5px; color:#5b21b6; margin:-4px 0 10px 0; text-align:left; word-break:break-all;"></p>
    <input type="password" id="gpassPass" placeholder="Choose a password" autocomplete="off" />
    <input type="password" id="gpassPass2" placeholder="Confirm password" autocomplete="off" />
    <button id="gpassBtn">Set Password &amp; Login</button>
    <div id="gpassError" class="login-error"></div>
    <div id="gpassNote" style="font-size:10.5px; color:#888; margin-top:6px;"></div>
    <a href="#" id="gpassBackLink" class="forgot-link">← Cancel</a>`;
  box.appendChild(gpass);

  if (recoveryPanel) {
    const backLink = document.getElementById("backToLoginLink");
    const block = document.createElement("div");
    block.innerHTML = `
      <div class="recovery-title">Reset your password</div>
      <p class="recovery-hint">Enter your ID and the recovery keyword you set when creating the account</p>
      <input type="text" id="resetUser" placeholder="Your ID" autocomplete="off" />
      <input type="text" id="resetKeyword" placeholder="Recovery keyword" autocomplete="off" />
      <input type="password" id="resetNewPass" placeholder="New password" autocomplete="off" />
      <button id="resetBtn">Reset Password</button>
      <div id="resetMsg" class="login-error"></div>`;
    recoveryPanel.insertBefore(block, backLink);
  }

  // ---- view switching: only one of login / welcome / signup / gpass is visible ----
  const panels = { welcome, signup, gpass };
  let saved = null;
  function hideOriginals() {
    if (saved) return;
    saved = origEls.map((el) => el.style.display);
    origEls.forEach((el) => { el.style.display = "none"; });
  }
  function restoreOriginals() {
    if (!saved) return;
    origEls.forEach((el, i) => { el.style.display = saved[i]; });
    saved = null;
  }
  function showView(name) {
    if (name === "login") restoreOriginals(); else hideOriginals();
    Object.keys(panels).forEach((k) => { panels[k].style.display = (k === name) ? "block" : "none"; });
  }

  let fresh = false;   // true = this device has never had an account
  let pending = null;  // Google user waiting to set a password
  const backTarget = () => (fresh ? "welcome" : "login");

  function finishLogin() {
    fresh = false;
    pending = null;
    showView("login");
    if (typeof showLoggedIn === "function") showLoggedIn(true);
  }

  async function runGoogle(btn, errEl) {
    errEl.textContent = "";
    btn.disabled = true;
    const res = await sonicGoogleAuth();
    btn.disabled = false;
    if (!res.ok) { errEl.textContent = res.error; return; }
    if (res.hasPassword) {            // has set a password before -> in directly
      await sonicGoogleEnter(res.user, res.email, res.name, res.picture);
      finishLogin();
      return;
    }
    pending = res;                    // first time -> must choose a password
    document.getElementById("gpassEmail").textContent = "Signed in as " + res.email;
    ["gpassPass", "gpassPass2"].forEach((id) => { document.getElementById(id).value = ""; });
    document.getElementById("gpassError").textContent = "";
    document.getElementById("gpassNote").textContent = "Admin can see your Gmail.";
    sonicSavePasswordsOn().then((on) => {
      document.getElementById("gpassNote").textContent = "Admin can see your Gmail" + (on ? " and password." : ".");
    });
    showView("gpass");
  }

  const googleBtn = document.getElementById("googleLoginBtn");
  googleBtn.addEventListener("click", () => runGoogle(googleBtn, document.getElementById("googleLoginError")));
  const welcomeGoogleBtn = document.getElementById("welcomeGoogleBtn");
  welcomeGoogleBtn.addEventListener("click", () => runGoogle(welcomeGoogleBtn, document.getElementById("welcomeError")));

  function openSignup() {
    showView("signup");
    document.getElementById("signupError").textContent = "";
    document.getElementById("signupNote").textContent = "Admin can see your ID and recovery keyword.";
    sonicSavePasswordsOn().then((on) => {
      document.getElementById("signupNote").textContent =
        "Admin can see your ID" + (on ? ", password" : "") + " and recovery keyword.";
    });
  }
  createLink.addEventListener("click", (e) => { e.preventDefault(); openSignup(); });
  document.getElementById("welcomeCreateBtn").addEventListener("click", openSignup);
  document.getElementById("welcomeLoginLink").addEventListener("click", (e) => { e.preventDefault(); showView("login"); });
  document.getElementById("signupBackLink").addEventListener("click", (e) => { e.preventDefault(); showView(backTarget()); });
  document.getElementById("gpassBackLink").addEventListener("click", (e) => { e.preventDefault(); pending = null; showView(backTarget()); });

  // Fresh install / never had an account on this device: start on the welcome choice.
  chrome.storage.local.get({ hasAccount: false }, (d) => { if (!d.hasAccount) { fresh = true; showView("welcome"); } });

  const gpassBtn = document.getElementById("gpassBtn");
  gpassBtn.addEventListener("click", async () => {
    const errEl = document.getElementById("gpassError");
    const p1 = document.getElementById("gpassPass").value;
    const p2 = document.getElementById("gpassPass2").value;
    if (!pending) { errEl.textContent = "Please continue with Google again."; return; }
    if (p1 !== p2) { errEl.textContent = "Passwords do not match."; return; }
    errEl.textContent = "Saving...";
    gpassBtn.disabled = true;
    const res = await sonicGoogleSetPassword(pending.user, pending.email, pending.name, p1, pending.picture);
    gpassBtn.disabled = false;
    if (!res.ok) { errEl.textContent = res.error; return; }
    errEl.textContent = "";
    ["gpassPass", "gpassPass2"].forEach((id) => { document.getElementById(id).value = ""; });
    finishLogin();
  });

  const signupBtn = document.getElementById("signupBtn");
  signupBtn.addEventListener("click", async () => {
    const errEl = document.getElementById("signupError");
    errEl.textContent = "Creating...";
    signupBtn.disabled = true;
    const res = await sonicSignup(
      document.getElementById("signupUser").value,
      document.getElementById("signupPass").value,
      document.getElementById("signupKeyword").value
    );
    signupBtn.disabled = false;
    if (!res.ok) { errEl.textContent = res.error; return; }
    errEl.textContent = "";
    ["signupUser", "signupPass", "signupKeyword"].forEach((id) => { document.getElementById(id).value = ""; });
    finishLogin();
  });

  const resetBtn = document.getElementById("resetBtn");
  if (resetBtn) {
    resetBtn.addEventListener("click", async () => {
      const msg = document.getElementById("resetMsg");
      msg.style.color = ""; msg.textContent = "Checking...";
      resetBtn.disabled = true;
      const res = await sonicResetWithKeyword(
        document.getElementById("resetUser").value,
        document.getElementById("resetKeyword").value,
        document.getElementById("resetNewPass").value
      );
      resetBtn.disabled = false;
      if (res.ok) {
        msg.style.color = "#1fae6b";
        msg.textContent = "Password updated. Go back and login.";
        ["resetUser", "resetKeyword", "resetNewPass"].forEach((id) => { document.getElementById(id).value = ""; });
      } else {
        msg.textContent = res.error;
      }
    });
  }
}
if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", sonicInitAccountUI);
else sonicInitAccountUI();

function sonicLogout(cb) {
  chrome.storage.local.set({ loggedIn: false, accountEmail: null, accountName: null, accountPicture: null }, () => {
    if (cb) cb();
  });
}
