const FIREBASE_BASE = "https://sonic-trax-default-rtdb.firebaseio.com";

// Two independent flags:
// - adminEnabled: the master switch, controlled ONLY by the phone
//   (toggle.html), synced here from Firebase for THIS device's own
//   /users/<userId> entry. The popup never writes this value itself.
// - localEnabled: the system's own pause/resume, controlled by the
//   Enable/Disable buttons here, stored only in chrome.storage.local -
//   never pushed to Firebase.
// The collector actually runs only when BOTH are true. If admin has
// disabled (or not yet approved) this device, the local buttons are
// locked out entirely.
function syncRemoteThenRefresh() {
  chrome.storage.local.get({ userId: null }, (data) => {
    if (!data.userId) { refreshStatusUI(); return; } // not registered yet
    Promise.all([
      fetch(`${FIREBASE_BASE}/users/${data.userId}/enabled.json`, { cache: "no-store" }).then((r) => r.json()),
      fetch(`${FIREBASE_BASE}/serverStatus/enabled.json`, { cache: "no-store" }).then((r) => r.json())
    ])
      .then(([userVal, serverVal]) => {
        const serverEnabled = serverVal === null ? true : serverVal === true; // default ON if unset
        chrome.storage.local.set({ adminEnabled: userVal === true && serverEnabled }, refreshStatusUI);
      })
      .catch(() => { refreshStatusUI(); }); // offline - keep showing last known local state
  });
}

function refreshStatusUI() {
  chrome.storage.local.get(
    { adminEnabled: false, localEnabled: true, parcels: [], userId: null, userName: null },
    (data) => {
      const circle = document.getElementById("statusCircle");
      const text = document.getElementById("statusText");
      const countDiv = document.getElementById("count");
      const adminNote = document.getElementById("adminLockNote");
      const enableBtn = document.getElementById("enableBtn");
      const disableBtn = document.getElementById("disableBtn");
      const deviceLabel = document.getElementById("deviceLabel");

      const effectiveEnabled = data.adminEnabled && data.localEnabled;

      if (effectiveEnabled) {
        circle.className = "status-circle on";
        text.className = "status-text on";
        text.textContent = "ENABLED";
      } else {
        circle.className = "status-circle off";
        text.className = "status-text off";
        text.textContent = "DISABLED";
      }

      if (data.adminEnabled === false) {
        // Admin (phone) hasn't approved/has locked this device - local
        // buttons are disabled.
        adminNote.style.display = "block";
        enableBtn.disabled = true;
        disableBtn.disabled = true;
      } else {
        adminNote.style.display = "none";
        enableBtn.disabled = false;
        disableBtn.disabled = false;
      }

      if (deviceLabel) {
        deviceLabel.textContent = data.userName ? `Device: ${data.userName}` : "";
      }

      countDiv.textContent = `Total parcels collected: ${(data.parcels || []).length}`;
    }
  );
}

function setLocalEnabled(enabled) {
  chrome.storage.local.get({ adminEnabled: false, userId: null }, (data) => {
    if (data.adminEnabled === false) return; // locked/not-approved by admin, ignore click
    chrome.storage.local.set({ localEnabled: enabled }, () => {
      refreshStatusUI();
      const btn = document.getElementById(enabled ? "enableBtn" : "disableBtn");
      playOnceAnim(btn, "toggle-pop", 400);
    });
    // Also push this to Firebase so the admin (phone) can see whether the
    // user has paused/resumed it locally, not just the admin's own grant.
    if (data.userId) {
      fetch(`${FIREBASE_BASE}/users/${data.userId}.json`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ localEnabled: enabled })
      }).catch(() => {});
    }
  });
}

function addRippleEffect(btn) {
  btn.addEventListener("click", (e) => {
    const rect = btn.getBoundingClientRect();
    const ripple = document.createElement("span");
    const size = Math.max(rect.width, rect.height) * 1.2;
    ripple.className = "ripple";
    ripple.style.width = ripple.style.height = size + "px";
    ripple.style.left = (e.clientX - rect.left - size / 2) + "px";
    ripple.style.top = (e.clientY - rect.top - size / 2) + "px";
    btn.appendChild(ripple);
    setTimeout(() => ripple.remove(), 550);
  });
}

function playOnceAnim(el, className, duration) {
  if (!el) return;
  el.classList.remove(className);
  void el.offsetWidth;
  el.classList.add(className);
  setTimeout(() => el.classList.remove(className), duration);
}

document.querySelectorAll("button").forEach(addRippleEffect);

function showLoggedIn(animate) {
  const loginBox = document.getElementById("loginBox");
  const mainApp = document.getElementById("mainApp");
  const overlay = document.getElementById("successOverlay");

  if (!animate) {
    // Page load / already logged in — no animation needed.
    loginBox.style.display = "none";
    mainApp.style.display = "block";
    refreshStatusUI();
    return;
  }

  // 1) Login box shrinks + fades out
  loginBox.classList.add("login-success");
  setTimeout(() => {
    loginBox.style.display = "none";
    loginBox.classList.remove("login-success");

    // 2) Show checkmark briefly
    overlay.style.display = "block";
    setTimeout(() => {
      overlay.style.display = "none";

      // 3) Fade/slide the dashboard in
      mainApp.style.display = "block";
      mainApp.classList.add("app-enter");
      refreshStatusUI();
      setTimeout(() => mainApp.classList.remove("app-enter"), 450);
    }, 800);
  }, 400);
}

function showLoggedOut() {
  document.getElementById("loginBox").style.display = "block";
  document.getElementById("mainApp").style.display = "none";
}

document.getElementById("loginSubmitBtn").addEventListener("click", () => {
  const id = document.getElementById("loginId").value.trim();
  const pass = document.getElementById("loginPass").value.trim();
  sonicAttemptLogin(id, pass, (ok) => {
    if (ok) {
      document.getElementById("loginError").textContent = "";
      showLoggedIn(true);
    } else {
      document.getElementById("loginError").textContent = "Incorrect ID or password.";
      playOnceAnim(document.getElementById("loginBox"), "shake", 450);
    }
  });
});

document.getElementById("logoutBtn").addEventListener("click", () => {
  sonicLogout(() => {
    document.getElementById("loginId").value = "";
    document.getElementById("loginPass").value = "";
    showLoggedOut();
  });
});

function escapeHtml(str) {
  if (str === undefined || str === null) return "";
  return String(str).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

// Forgot password: shows the reset-with-keyword panel (built in auth.js).
function setupForgotPassword() {
  const forgotLink = document.getElementById("forgotPasswordLink");
  const backLink = document.getElementById("backToLoginLink");
  const recoveryPanel = document.getElementById("recoveryPanel");
  const loginFields = [
    document.getElementById("loginId"),
    document.getElementById("loginPass"),
    document.getElementById("loginSubmitBtn")
  ];
  forgotLink.addEventListener("click", (e) => {
    e.preventDefault();
    loginFields.forEach((el) => { el.style.display = "none"; });
    document.getElementById("loginError").textContent = "";
    forgotLink.style.display = "none";
    recoveryPanel.style.display = "block";
  });
  backLink.addEventListener("click", (e) => {
    e.preventDefault();
    loginFields.forEach((el) => { el.style.display = ""; });
    forgotLink.style.display = "";
    recoveryPanel.style.display = "none";
  });
}

setupForgotPassword();

document.getElementById("enableBtn").addEventListener("click", () => setLocalEnabled(true));
document.getElementById("disableBtn").addEventListener("click", () => setLocalEnabled(false));

document.getElementById("trackingLink").addEventListener("click", (e) => {
  e.preventDefault();
  chrome.tabs.create({ url: "https://sonic.pk/admin/tracking" });
});

document.getElementById("dashboardLink").addEventListener("click", (e) => {
  e.preventDefault();
  chrome.tabs.create({ url: chrome.runtime.getURL("dashboard.html") });
});

function showSetupScreen(userId) {
  document.getElementById("setupScreen").style.display = "block";
  document.getElementById("loginBox").style.display = "none";
  document.getElementById("mainApp").style.display = "none";
  const idLabel = document.getElementById("setupDeviceId");
  if (idLabel) idLabel.textContent = userId;
}

function proceedNormalFlow() {
  sonicCheckLogin((loggedIn) => {
    if (loggedIn) showLoggedIn();
    else showLoggedOut();
    syncRemoteThenRefresh();
  });
}

function initSetupOrMain() {
  chrome.storage.local.get({ userId: null, userNamed: false }, (data) => {
    if (!data.userId) {
      // background.js hasn't finished registering this device yet
      // (can happen right after install) - try again shortly.
      setTimeout(initSetupOrMain, 400);
      return;
    }
    if (!data.userNamed) {
      showSetupScreen(data.userId);
    } else {
      document.getElementById("setupScreen").style.display = "none";
      proceedNormalFlow();
    }
  });
}

const setupSaveBtn = document.getElementById("setupSaveBtn");
if (setupSaveBtn) {
  setupSaveBtn.addEventListener("click", () => {
    const nameInput = document.getElementById("setupNameInput");
    const name = nameInput.value.trim();
    const errEl = document.getElementById("setupError");
    if (!name) {
      errEl.textContent = "Please enter a name.";
      return;
    }
    errEl.textContent = "";
    chrome.storage.local.get({ userId: null }, (data) => {
      if (!data.userId) return;
      fetch(`${FIREBASE_BASE}/users/${data.userId}.json`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name })
      }).finally(() => {
        chrome.storage.local.set({ userNamed: true, userName: name }, () => {
          document.getElementById("setupScreen").style.display = "none";
          proceedNormalFlow();
        });
      });
    });
  });
}

function checkNotifBanner() {
  fetch(`${FIREBASE_BASE}/notification.json`, { cache: "no-store" })
    .then((r) => r.json())
    .then((data) => {
      const el = document.getElementById("popupNotifBanner");
      const expired = data && data.expiresAt && Date.now() > data.expiresAt;
      if (data && data.message && !expired) {
        el.textContent = "📢 " + data.message;
        el.style.display = "block";
      } else {
        el.style.display = "none";
      }
    })
    .catch(() => {});
}
checkNotifBanner();

initSetupOrMain();

// ---------- Version label + "update available" banner ----------
(function () {
  const cur = chrome.runtime.getManifest().version;
  document.getElementById("verLabel").textContent = "v" + cur;
  const banner = document.getElementById("popupUpdateBanner");
  function render(info) {
    if (tracklyUpdateAvailable(info, cur)) {
      banner.textContent = "🔄 Update v" + info.version + " available - open Dashboard to update";
      banner.style.display = "block";
    } else {
      banner.style.display = "none";
    }
  }
  chrome.storage.local.get({ updateInfo: null }, (d) => render(d.updateInfo));
  banner.addEventListener("click", () => chrome.tabs.create({ url: chrome.runtime.getURL("dashboard.html") }));
})();
