// background.js
// Multi-user admin access control:
// - Every install of this extension gets its own persistent device ID
//   and registers itself under /users/<userId> in Firebase, starting
//   DISABLED (enabled: false) until the admin turns it ON from the phone
//   control page (toggle.html) - which lists every registered device.
// - This service worker periodically re-checks /users/<userId>/enabled
//   and mirrors it into chrome.storage.local as "adminEnabled" - the
//   master switch that content.js/popup.js/dashboard.js all read.
// - A separate "localEnabled" flag (controlled by the popup's own
//   Enable/Disable buttons) is local-only and never touches Firebase -
//   it only works while the admin has this device's "adminEnabled" ON.

importScripts("updater.js");

const FIREBASE_BASE = "https://sonic-trax-default-rtdb.firebaseio.com";
const ALARM_NAME = "sonicRemoteSync";

function generateUserId() {
  return "user_" + Math.random().toString(36).slice(2, 8) + Date.now().toString(36).slice(-4);
}

async function ensureRegistered() {
  const data = await chrome.storage.local.get({
    userId: null,
    registeredWithFirebase: false,
    localEnabled: true
  });

  let userId = data.userId;
  if (!userId) {
    userId = generateUserId();
    await chrome.storage.local.set({ userId });
  }
  if (data.localEnabled === undefined) {
    await chrome.storage.local.set({ localEnabled: true });
  }

  if (!data.registeredWithFirebase) {
    try {
      await fetch(`${FIREBASE_BASE}/users/${userId}.json`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ enabled: false, name: "New Device", registeredAt: Date.now() })
      });
      await chrome.storage.local.set({ registeredWithFirebase: true });
    } catch (e) {
      // Offline right now - registeredWithFirebase stays false, so this
      // will retry automatically on the next install/startup event.
    }
  }

  return userId;
}

async function syncFromFirebase() {
  const data = await chrome.storage.local.get({ userId: null, registeredWithFirebase: false, localEnabled: true });
  if (!data.userId) return;

  // Heartbeat - lets the admin panel show "last seen" and the user's own
  // local pause/resume state for this device.
  try {
    await fetch(`${FIREBASE_BASE}/users/${data.userId}.json`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ lastSeen: Date.now(), localEnabled: data.localEnabled })
    });
  } catch (e) {
    // Not critical if this fails - just try again next cycle.
  }

  try {
    const res = await fetch(`${FIREBASE_BASE}/users/${data.userId}/enabled.json`, { cache: "no-store" });
    if (!res.ok) return;
    const remoteValue = await res.json(); // true, false, or null (not registered / removed)

    if (remoteValue === null && data.registeredWithFirebase) {
      // The admin deleted this device's entry - re-register it (starts
      // DISABLED again, awaiting re-approval) instead of staying stuck.
      await chrome.storage.local.set({ registeredWithFirebase: false, adminEnabled: false });
      await ensureRegistered();
      return;
    }

    // Global master switch (Server Control tab) - if the server itself is
    // disabled, nothing runs regardless of this device's own approval.
    let serverEnabled = true;
    try {
      const sRes = await fetch(`${FIREBASE_BASE}/serverStatus/enabled.json`, { cache: "no-store" });
      if (sRes.ok) {
        const sVal = await sRes.json();
        if (sVal !== null) serverEnabled = sVal === true;
      }
    } catch (e) {
      // Leave serverEnabled at its default (true) on a network hiccup.
    }

    const effective = remoteValue === true && serverEnabled;
    chrome.storage.local.get({ adminEnabled: false }, (d) => {
      if (d.adminEnabled !== effective) {
        chrome.storage.local.set({ adminEnabled: effective });
        console.log("[Sonic Collector] Admin status changed -> " + (effective ? "ENABLED" : "DISABLED"));
      }
    });
  } catch (e) {
    // Network hiccup / offline - just try again on the next alarm.
  }
}

async function init() {
  await ensureRegistered();
  chrome.alarms.create(ALARM_NAME, { periodInMinutes: 1 });
  syncFromFirebase();
  tracklyCheckForUpdate(false);
}

chrome.runtime.onInstalled.addListener(init);
chrome.runtime.onStartup.addListener(init);

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === ALARM_NAME) { syncFromFirebase(); tracklyCheckForUpdate(false); }
});
