// updater.js - free auto-update system (GitHub based).
// - background.js checks version.json on GitHub every few hours and stores
//   the result in chrome.storage.local ("updateInfo"), showing a NEW badge.
// - The dashboard shows an "Update now" bar. One click downloads latest.zip,
//   checks its SHA-256 fingerprint, writes the files into the extension's own
//   folder (chosen once by the user) and reloads the extension.
// Safe to load in the service worker, the popup and the dashboard.

const TRACKLY_UPDATE_BASE = "https://raw.githubusercontent.com/Usama123-ai/trackly-updates/main/";
const TRACKLY_CHECK_EVERY_MS = 3 * 60 * 60 * 1000; // 3 hours

function tracklyCompareVersions(a, b) {
  const pa = String(a).split(".").map((n) => parseInt(n, 10) || 0);
  const pb = String(b).split(".").map((n) => parseInt(n, 10) || 0);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const x = pa[i] || 0, y = pb[i] || 0;
    if (x > y) return 1;
    if (x < y) return -1;
  }
  return 0;
}

function tracklyUpdateAvailable(info, current) {
  return !!(info && info.version && tracklyCompareVersions(info.version, current) > 0);
}

function tracklyUpdateBadge(info, current) {
  try {
    if (tracklyUpdateAvailable(info, current)) {
      chrome.action.setBadgeText({ text: "NEW" });
      chrome.action.setBadgeBackgroundColor({ color: "#7c3aed" });
    } else {
      chrome.action.setBadgeText({ text: "" });
    }
  } catch (e) {}
}

// force=false -> only hits GitHub if the last try was more than 3 hours ago.
async function tracklyCheckForUpdate(force) {
  const current = chrome.runtime.getManifest().version;
  const st = await chrome.storage.local.get({ updateInfo: null, updateLastTry: 0 });
  if (!force && Date.now() - st.updateLastTry < TRACKLY_CHECK_EVERY_MS) {
    tracklyUpdateBadge(st.updateInfo, current);
    return st.updateInfo;
  }
  await chrome.storage.local.set({ updateLastTry: Date.now() });
  try {
    const res = await fetch(TRACKLY_UPDATE_BASE + "version.json?t=" + Date.now(), { cache: "no-store" });
    if (!res.ok) throw new Error("HTTP " + res.status);
    const j = await res.json();
    const info = {
      version: String(j.version || ""),
      sha256: String(j.sha256 || "").toLowerCase(),
      notes: String(j.notes || ""),
      checkedAt: Date.now()
    };
    await chrome.storage.local.set({ updateInfo: info });
    tracklyUpdateBadge(info, current);
    return info;
  } catch (e) {
    return st.updateInfo; // offline / GitHub unreachable - keep last known info
  }
}

// ---------- remembers the chosen extension folder (IndexedDB) ----------
function tracklyIdb() {
  return new Promise((res, rej) => {
    const r = indexedDB.open("trackly-updater", 1);
    r.onupgradeneeded = () => r.result.createObjectStore("kv");
    r.onsuccess = () => res(r.result);
    r.onerror = () => rej(r.error);
  });
}
async function tracklyIdbGet(k) {
  const db = await tracklyIdb();
  return new Promise((res, rej) => {
    const q = db.transaction("kv").objectStore("kv").get(k);
    q.onsuccess = () => res(q.result);
    q.onerror = () => rej(q.error);
  });
}
async function tracklyIdbSet(k, v) {
  const db = await tracklyIdb();
  return new Promise((res, rej) => {
    const t = db.transaction("kv", "readwrite");
    t.objectStore("kv").put(v, k);
    t.oncomplete = () => res();
    t.onerror = () => rej(t.error);
  });
}
async function tracklyIdbDel(k) {
  const db = await tracklyIdb();
  return new Promise((res, rej) => {
    const t = db.transaction("kv", "readwrite");
    t.objectStore("kv").delete(k);
    t.oncomplete = () => res();
    t.onerror = () => rej(t.error);
  });
}

// Must run directly from a click (browser needs the user gesture).
async function tracklyGetFolder() {
  let h = null;
  try { h = await tracklyIdbGet("extDir"); } catch (e) {}
  if (h) {
    try {
      let p = await h.queryPermission({ mode: "readwrite" });
      if (p !== "granted") p = await h.requestPermission({ mode: "readwrite" });
      if (p === "granted") return h;
    } catch (e) {}
  }
  h = await window.showDirectoryPicker({ id: "trackly-ext", mode: "readwrite" });
  await tracklyIdbSet("extDir", h);
  return h;
}

async function tracklyVerifyFolder(dir) {
  try {
    const fh = await dir.getFileHandle("manifest.json");
    const m = JSON.parse(await (await fh.getFile()).text());
    return !!m && m.name === chrome.runtime.getManifest().name;
  } catch (e) { return false; }
}

async function tracklyApplyUpdate(progress) {
  const say = progress || function () {};
  const current = chrome.runtime.getManifest().version;

  say("Select your Trackly extension folder (the one used for Load unpacked)...");
  const dir = await tracklyGetFolder();
  if (!(await tracklyVerifyFolder(dir))) {
    await tracklyIdbDel("extDir").catch(() => {});
    throw new Error("WRONG_FOLDER");
  }

  say("Checking latest version...");
  const info = await tracklyCheckForUpdate(true);
  if (!tracklyUpdateAvailable(info, current)) throw new Error("NO_UPDATE");

  say("Downloading v" + info.version + "...");
  const res = await fetch(TRACKLY_UPDATE_BASE + "latest.zip?t=" + Date.now(), { cache: "no-store" });
  if (!res.ok) throw new Error("DOWNLOAD_FAILED");
  const buf = await res.arrayBuffer();

  if (info.sha256) {
    const d = await crypto.subtle.digest("SHA-256", buf);
    const hex = Array.from(new Uint8Array(d)).map((b) => b.toString(16).padStart(2, "0")).join("");
    if (hex !== info.sha256) throw new Error("HASH_MISMATCH");
  }

  const zip = await JSZip.loadAsync(buf);
  let mpath = null;
  zip.forEach((p, f) => {
    if (!f.dir && /(^|\/)manifest\.json$/.test(p) && (mpath === null || p.split("/").length < mpath.split("/").length)) mpath = p;
  });
  if (!mpath) throw new Error("BAD_ZIP");
  const prefix = mpath.slice(0, mpath.length - "manifest.json".length);
  const newManifest = JSON.parse(await zip.file(mpath).async("string"));
  if (newManifest.version !== info.version) throw new Error("BAD_ZIP");

  const entries = [];
  zip.forEach((p, f) => {
    if (f.dir || !p.startsWith(prefix) || p === mpath) return;
    const rel = p.slice(prefix.length);
    if (rel.startsWith("__MACOSX")) return;
    entries.push([rel, f]);
  });
  entries.push(["manifest.json", zip.file(mpath)]); // written last

  let n = 0;
  for (const [rel, f] of entries) {
    say("Updating files " + (++n) + "/" + entries.length + "...");
    const parts = rel.split("/");
    const name = parts.pop();
    if (!name || parts.some((s) => !s || s === "." || s === "..")) continue; // path safety
    let d = dir;
    for (const s of parts) d = await d.getDirectoryHandle(s, { create: true });
    const fh = await d.getFileHandle(name, { create: true });
    const w = await fh.createWritable();
    await w.write(await f.async("blob"));
    await w.close();
  }

  say("Done! Restarting Trackly...");
  setTimeout(() => chrome.runtime.reload(), 800);
}
