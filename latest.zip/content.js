// content.js
// This script ALWAYS runs on the sonic.pk tracking page. It handles both
// single tracking and BULK tracking (when one page shows results for many
// parcels stacked one after another) - for each parcel it finds that
// parcel's own tracking-number header and pulls the data only from that
// section (block).

(function () {
  let attemptNum = 0;

  // Real historical (DBF Remarks, Reason) pairs collected from past
  // reports, grouped by Rider Status. When we save a new parcel with a
  // matching Rider Status, we randomly pick one of these real pairs so
  // the auto-filled remark/reason looks like an authentic manual entry
  // instead of always writing the exact same fixed phrase.
  const RIDER_STATUS_HISTORY = {"Change of Mind": [{"remark": "ye to man ne cancel kiya tha", "reason": "nai lena"}, {"remark": "man ne koi order nai kiya", "reason": "refuse"}, {"remark": "Pehly b kaha tha k nai lena", "reason": "refuse"}, {"remark": "return kr den ye hum ne nai lena", "reason": "nai lena"}, {"remark": "nai lena wapis kr den", "reason": "nai lena"}, {"remark": "man ne order nai kiya dost ne kiya tha wo nai hai", "reason": "wapis kr den"}, {"remark": "Rider ko btaya tha k nai chahiye", "reason": "nai lena"}, {"remark": "ye hum ne usi wqt cancel kr diya tha", "reason": "cancelled"}, {"remark": "wapis kr den ye man cancel kr diya tha", "reason": "refuse"}, {"remark": "abi ghr koi b nai hai man aa kr khud lun ga", "reason": "out of city hun"}, {"remark": "man ne ye refuse kr diya tha", "reason": "nai lena"}, {"remark": "pehly b btaya tha k man ne koi order nai kiya", "reason": "refuse"}, {"remark": "man ne koi order nai kiya", "reason": "wapis kr den"}, {"remark": "rider ko bataya tha k nai lena", "reason": "refuse"}, {"remark": "ye hum ne usi wqt cancel kr diya tha", "reason": "refuse"}, {"remark": "Rider ko btaya tha k nai chahiye", "reason": "refuse"}, {"remark": "jab lana huwa call kar dy gy", "reason": "Refuse"}, {"remark": "wapis kr den ye man cancel kr diya tha", "reason": "wapis kr den"}, {"remark": "man abi out of city hun aoun ga to call karun ga", "reason": "wapis kr den"}, {"remark": "bad my btata ho", "reason": "nai lena"}, {"remark": "nhi lana", "reason": "nhi lana"}, {"remark": "man ne koi order nai kiya", "reason": "nai lena"}, {"remark": "call nhi attend ki", "reason": "refuse"}, {"remark": "mara order nhi ihy", "reason": "Refuse"}, {"remark": "abi hum ghr nai han jb ayen gy to call kar den gy", "reason": "refuse"}, {"remark": "nai lena wapis kr den", "reason": "wapis kr den"}, {"remark": "hum ne nai lena wapis kr den", "reason": "nai lena"}, {"remark": "ghr nai hun ap wapis kr den", "reason": "refuse"}, {"remark": "bad my btata ho", "reason": "refuse"}, {"remark": "Bht din pehly order kiya tha ab nai lena", "reason": "Late aya hai"}, {"remark": "hum ne nai lena wapis kr den", "reason": "refuse"}, {"remark": "out of city ho return kar do", "reason": "refuse"}, {"remark": "1 or order kiya hai wo lena hai", "reason": "Place another order"}, {"remark": "2 or order kiya hai wo lena hai", "reason": "Place another order"}, {"remark": "man ne ye refuse kr diya tha", "reason": "refuse"}, {"remark": "nai lena rider ko b bataya tha", "reason": "wapis kr den"}, {"remark": "mara order nhi hy", "reason": "Refuse"}, {"remark": "galti sy order ho gya tha", "reason": "nai lena"}, {"remark": "ye man ne pehly he refuse kr diya tha", "reason": "wapis kr den"}, {"remark": "rider ko bataya tha k nai lena", "reason": "nai lena"}, {"remark": "jis ne order kiya tha wo chala gya hai", "reason": "nai lena"}, {"remark": "mera koi order nai hai", "reason": "nai lena"}, {"remark": "nai lena rider ko b bataya tha", "reason": "nai lena"}, {"remark": "ye hum ne usi wqt cancel kr diya tha", "reason": "nai lena"}, {"remark": "jis ne order kiya tha wo chala gya hai", "reason": "wapis kr den"}, {"remark": "Pehly b kaha tha k nai lena", "reason": "nai lena"}, {"remark": "mara order nhi hy", "reason": "mara order nhi hy"}, {"remark": "bhai ko puch kr btaoun ga", "reason": "nai lena"}, {"remark": "Guest aye thy unho ne order kiya tha", "reason": "oreder nai kiya tha"}, {"remark": "mara order nhi ihy", "reason": "wapis kr den"}, {"remark": "subha time b bataya tha k nai lena", "reason": "wapis kr den"}, {"remark": "wapis kr den ye man cancel kr diya tha", "reason": "Refuse"}, {"remark": "Kal b CNIC nai diya aj b", "reason": "CNIC nai diya"}, {"remark": "call nhi attend ki", "reason": "Refuse"}, {"remark": "abi confirm nai kiya tha unho ne bhej diya", "reason": "itni jaldi aa gya"}, {"remark": "man ne koi order nai kiya", "reason": "no order"}, {"remark": "return kr den ye hum ne nai lena", "reason": "return kt den"}, {"remark": "man be kuch order nai kiya", "reason": "nai lena"}, {"remark": "hum ne koi order nai kiya", "reason": "wapis kr den"}, {"remark": "ye hum ne usi wqt cancel kr diya tha", "reason": "wapis kr den"}, {"remark": "nai lena wapis kr den", "reason": "refuse"}, {"remark": "ye hum ne cancel kr diya tha", "reason": "nai lena"}, {"remark": "rider b btaya tha k man ne koi order nai kiya", "reason": "refuse"}, {"remark": "bhai  kehta return kr den", "reason": "nai lena"}, {"remark": "man ne koi order nai kiya", "reason": "cancelled"}, {"remark": "Purchased From Outlet", "reason": "Purchased From Outlet"}, {"remark": "man ne kuch order nai kiya", "reason": "nai lena"}, {"remark": "jis ne order kiya tha wo chala gya hai", "reason": "refuse"}, {"remark": "mera koi order nai hai", "reason": "wapis kr den"}, {"remark": "rider ko bataya tha k nai lena", "reason": "wapis kr den"}, {"remark": "jab lana huwa again order kar dy gy", "reason": "Refuse"}, {"remark": "galti sy order ho gya tha", "reason": "wapis kr den"}, {"remark": "rider ko kaha hai nai lena bar bar q tang kr rahy ho", "reason": "refuse"}, {"remark": "nai lena ap isy return kr den", "reason": "nai lena"}, {"remark": "hum ne koi order nai kiya", "reason": "refuse"}, {"remark": "hum ne ye cancel kr diya tha", "reason": "wapis kr den"}, {"remark": "Rider ko b btaya tha k nai chahiye", "reason": "nai lena"}, {"remark": "ye retun kr den rider ko b kha tha", "reason": "nai lena"}, {"remark": "nhi lana", "reason": "refuse"}, {"remark": "Double order ho gya tha", "reason": "Already received"}, {"remark": "Consignee Unavailable", "reason": "Unavailable"}, {"remark": "Rider ko b btaya tha k nai chahiye", "reason": "Unavailable"}, {"remark": "ye hum ne usi wqt cancel kr diya tha", "reason": "Unavailable"}, {"remark": "Quality Issue", "reason": "Quality Issue"}, {"remark": "open kar ky receive krna hy", "reason": "nai lena"}, {"remark": "Pehly khol kr check karun ga phr lun ga", "reason": "wapis kr den"}, {"remark": "number off", "reason": "number off"}, {"remark": "wapis kr den ye man cancel kr diya tha", "reason": "Unavailable"}, {"remark": "Pehly khol kr check karun ga phr lun ga", "reason": "khol kr lena hai"}, {"remark": "ye to man ne cancel kiya tha", "reason": "cancelled"}, {"remark": "ye hum ne pehly he cancel kiya hai", "reason": "nai lena"}, {"remark": "1 or order kiya hai wo lena hai ye nai", "reason": "Place another order"}, {"remark": "hum ne ye cancel kr diya tha", "reason": "refuse"}, {"remark": "Rider ko btaya tha k nai chahiye", "reason": "wapis kr den"}, {"remark": "nai lena jis ne order kiya tha wo nai hai", "reason": "nai lena"}, {"remark": "ye man ne cancel kr diya tha", "reason": "nai lena"}, {"remark": "Bht din pehly order kiya tha ab nai lena", "reason": "late aya hai"}, {"remark": "ye retun kr den rider ko b kha tha", "reason": "refuse"}, {"remark": "nai lena wapis kr den", "reason": "cancelled"}, {"remark": "Man ne to account he bnd karwa diya hai", "reason": "wapis kr den"}, {"remark": "Pehly b kaha tha k nai lena", "reason": "Fake Reattempt"}, {"remark": "ghr nai hun ap wapis kr call karun ga", "reason": "refuse"}, {"remark": "ye man ne usi time cancel kr diya tha", "reason": "wapis kr den"}, {"remark": "Refuse", "reason": "Refuse"}, {"remark": "Okara Mein Nahi Ho", "reason": "Refuse"}, {"remark": "jab lana huwa call kar ly gy", "reason": "refuse"}, {"remark": "Not Intersted", "reason": "refuse"}, {"remark": "open kar ky receive krna hy", "reason": "Refuse"}, {"remark": "nhi lana", "reason": "Nhi lana"}, {"remark": "wapis kar den", "reason": "refuse"}, {"remark": "bhai hum ne koi order nai kiya", "reason": "no order"}, {"remark": "Gaon aa k dy k jao", "reason": "refuse"}, {"remark": "number off", "reason": "refuse"}, {"remark": "Number off", "reason": "number off"}, {"remark": "out of city ho return kar do", "reason": "Refuse"}, {"remark": "Address pora nhi hy", "reason": "refuse"}, {"remark": "parcel ka sun kar call cut kar di", "reason": "parcel ka sun kar call cut kar di"}, {"remark": "out of city ho return kar do", "reason": "wapis kr den"}, {"remark": "Double order ho gya tha", "reason": "Already receive"}, {"remark": "Consignee Unavailable", "reason": "Consignee Unavailable"}, {"remark": "mara order nhi ihy", "reason": "refuse"}, {"remark": "bataya hai nai lena", "reason": "nai lena"}, {"remark": "Bht din pehly order kiya tha", "reason": "Late aya hai"}, {"remark": "Gaoun aa k dy k jao", "reason": "NSA"}, {"remark": "1or order kiya hai wo lena hai", "reason": "Place another order"}, {"remark": "wapis kr den ye man cancel kr diya tha", "reason": "Consignee Unavailable"}, {"remark": "Mera Order Nahi Hai", "reason": "Mera Order Nahi Hai"}, {"remark": "nhi lana", "reason": "Quality Issue"}, {"remark": "nhi lana", "reason": "ni lana"}, {"remark": "jab lana huwa call kar dy gy", "reason": "refuse"}, {"remark": "wapis kr den ye man cancel kr diya tha", "reason": "refuses"}, {"remark": "nhi lana", "reason": "Refuse"}, {"remark": "bachy ny order kiya tha", "reason": "Refuse"}, {"remark": "wapis kr den ye man cancel kr diya tha", "reason": "nai lena"}, {"remark": "1 or order ana hai wo lena hai", "reason": "Place another order"}, {"remark": "Man ne bazar sy ly liya hai", "reason": "Purchased From Outlet"}, {"remark": "Aik or order kiya hai wo lena hai ye nai", "reason": "Place another order"}, {"remark": "NSA Area", "reason": "NSA Area"}, {"remark": "many nhi lana", "reason": "refuse"}, {"remark": "nhi lana", "reason": "refue"}, {"remark": "pata nhi kis ny order kiya", "reason": "refuse"}, {"remark": "dobra order krna hy", "reason": "refuse"}, {"remark": "parcel ka sun kar call kar cut kar di", "reason": "refuse"}, {"remark": "wapis", "reason": "refuse"}, {"remark": "many osi time cancel kar diya tha", "reason": "refuse"}, {"remark": "bachy ny glati sy order kr diya", "reason": "refuse"}, {"remark": "jis ka tha wo yha nhi hy", "reason": "refuse"}, {"remark": "wapis kar dy", "reason": "refuse"}, {"remark": "rider ko phly btya nhi hy kyu ni lana", "reason": "refuse"}, {"remark": "wapis kar do", "reason": "refuse"}, {"remark": "bachy ny order kar diya tha", "reason": "refuse"}, {"remark": "pata nh kon mary name ka order kar rha hy", "reason": "refuse"}, {"remark": "refuse", "reason": "refuse"}, {"remark": "Double Order Ho Gaya Tha", "reason": "Double Order Ho Gaya Tha"}, {"remark": "bazar sy liya hai hai", "reason": "Purchased From Outlet"}, {"remark": "Place another order", "reason": "1 or ana hai wo lena hai"}, {"remark": "Amount Issue", "reason": "Amount Issue"}, {"remark": "opne kar ky receive krna hy", "reason": "wapis kr den"}, {"remark": "Gaoun aa k dy k jao", "reason": "nai lena"}, {"remark": "rider ly k aya tha tb b cancel kiya tha", "reason": "nai lena"}, {"remark": "jo mangwya wo nhi aya", "reason": "Refuse"}, {"remark": "man ne koi order nai kiya", "reason": ""}, {"remark": "ye hum ne usi wqt cancel kr diya tha", "reason": ""}, {"remark": "Call attend nai ki", "reason": "Not responding"}, {"remark": "man ne cancel kr diya tha", "reason": "nai lena"}], "Hold On Consignee Request": [{"remark": "Consignee Unavailable", "reason": "Unavailable"}, {"remark": "CNIC nai diya", "reason": "CNIC nai diya"}, {"remark": "2 din bad receive karna ha", "reason": "Unavailable"}, {"remark": "2 din tak office sa receive kary ga", "reason": "Unavailable"}, {"remark": "ghr nai hun ap wapis kr den", "reason": "refuse"}, {"remark": "Lahore main lena hai", "reason": "Wrong Destination"}, {"remark": "hum ne koi order nai kiya", "reason": "Unavailable"}, {"remark": "out of city ho return kar do", "reason": "nai lena"}, {"remark": "wapis kr den ye man cancel kr diya tha", "reason": "Amount issue"}, {"remark": "LAHORE MY LANA HY", "reason": "LAHORE MY LANA HY"}, {"remark": "ye to man ne cancel kiya tha", "reason": "nai lena"}, {"remark": "Okara Mein Nahi Ho", "reason": "Refuse"}, {"remark": "man ne koi order nai kiya", "reason": "refuse"}, {"remark": "Consignee Unavailable", "reason": "Consignee Unavailable"}, {"remark": "nhi lana", "reason": "refuse"}, {"remark": "jab lana huwa call kar dy gy", "reason": "refuse"}, {"remark": "consignee Unavailable", "reason": "consignee Unavailable"}, {"remark": "consignee Unavailable", "reason": "Unavailable"}, {"remark": "Address nhi hy", "reason": "refuse"}, {"remark": "call nhi attend ki", "reason": "refuse"}, {"remark": "wapis kr den ye man cancel kr diya tha", "reason": "nai lena"}, {"remark": "nai lena wapis kr den", "reason": "nai lena"}, {"remark": "Pakpattan main lena hai", "reason": "Wrong Destination"}, {"remark": "hum ne nai lena wapis kr den", "reason": "refuse"}, {"remark": "abi address par nhi ho", "reason": "refuse"}, {"remark": "Consignee Okara Ka Nahi Hy", "reason": "Consignee Okara Ka Nahi Hy"}, {"remark": "NSA Area", "reason": "NSA Area"}, {"remark": "return kr den ye hum ne nai lena", "reason": "nai lena"}, {"remark": "ye hum ne usi wqt cancel kr diya tha", "reason": "refuse"}, {"remark": "return kr den ye hum ne nai lena", "reason": "return kt den"}, {"remark": "address complete nhi hy", "reason": "nai lena"}], "Consignee Wants To Open The Shipment": [{"remark": "Pehly khol kr check karun ga phr lun ga", "reason": "khol kr lena hai"}, {"remark": "open kar ky receive krna hy", "reason": "wapis kr den"}, {"remark": "open kar ky receive krna hy", "reason": "nai lena"}, {"remark": "pehly Khol kr check karun ga phr lun ga", "reason": "khol kr lena hai"}, {"remark": "Pehly khol kr check karun phr lun ga", "reason": "khol kr lena hai"}, {"remark": "Khol Kar Receive Karna Hai", "reason": "Refuse"}, {"remark": "Pehly khol kr check karun ga phr lun ga", "reason": "Khol kr lena hai"}], "No Such Consignee Found": [{"remark": "man abi out of city hun aoun ga to call karun ga", "reason": "wapis kr den"}, {"remark": "nai lena wapis kr den", "reason": "wapis kr den"}, {"remark": "man ne koi order nai kiya", "reason": "no order"}, {"remark": "nai lena wapis kr den", "reason": "nai lena"}, {"remark": "nhi lana", "reason": "nhi lana"}, {"remark": "nai lena rider ko b bataya tha", "reason": "nai lena"}, {"remark": "galti sy order ho gya tha", "reason": "wapis kr den"}, {"remark": "ghr nai hun ap wapis kr den", "reason": "refuse"}, {"remark": "pehly b btaya tha k man ne koi order nai kiya", "reason": "refuse"}, {"remark": "ye hum ne usi wqt cancel kr diya tha", "reason": "nai lena"}, {"remark": "wapis kr den ye man cancel kr diya tha", "reason": "refuse"}, {"remark": "Bht din pehly order kiya tha", "reason": "Late aya hai"}, {"remark": "bhai  kehta return kr den", "reason": "nai lena"}, {"remark": "wapis kr den ye man cancel kr diya tha", "reason": "nai lena"}, {"remark": "out of city ho return kar do", "reason": "refuse"}, {"remark": "man ne ye refuse kr diya tha", "reason": "refuse"}, {"remark": "mara order nhi ihy", "reason": "wapis kr den"}, {"remark": "man ne koi order nai kiya", "reason": "nai lena"}, {"remark": "galti sy order ho gya tha", "reason": "nai lena"}, {"remark": "subha time b bataya tha k nai lena", "reason": "wapis kr den"}, {"remark": "man ne ye refuse kr diya tha", "reason": "nai lena"}, {"remark": "hum ne nai lena wapis kr den", "reason": "nai lena"}, {"remark": "hum ne nai lena wapis kr den", "reason": "refuse"}, {"remark": "bhai ko puch kr btaoun ga", "reason": "nai lena"}, {"remark": "wapis kr den ye man cancel kr diya tha", "reason": "wapis kr den"}, {"remark": "rider ko bataya tha k nai lena", "reason": "nai lena"}, {"remark": "abi ghr koi b nai hai man aa kr khud lun ga", "reason": "out of city hun"}, {"remark": "out of city ho return kar do", "reason": "wapis kr den"}, {"remark": "nai lena ap isy return kr den", "reason": "nai lena"}, {"remark": "ye hum ne usi wqt cancel kr diya tha", "reason": "refuse"}, {"remark": "man be kuch order nai kiya", "reason": "nai lena"}, {"remark": "jis ne order kiya tha wo chala gya hai", "reason": "wapis kr den"}, {"remark": "ye man ne pehly he refuse kr diya tha", "reason": "wapis kr den"}, {"remark": "Rider ko btaya tha k nai chahiye", "reason": "refuse"}, {"remark": "jo mangwya wo nhi aya", "reason": "Refuse"}, {"remark": "man ne koi order nai kiya", "reason": "wapis kr den"}, {"remark": "nai lena wapis kr den", "reason": "refuse"}, {"remark": "open kar ky receive krna hy", "reason": "nai lena"}, {"remark": "Quality Issue", "reason": "Quality Issue"}, {"remark": "ye to man ne cancel kiya tha", "reason": "nai lena"}, {"remark": "nhi lana", "reason": "refuse"}, {"remark": "Pehly b kaha tha k nai lena", "reason": "nai lena"}, {"remark": "man ne koi order nai kiya", "reason": "refuse"}, {"remark": "return kr den ye hum ne nai lena", "reason": "nai lena"}, {"remark": "nai lena rider ko b bataya tha", "reason": "wapis kr den"}, {"remark": "Rider ko btaya tha k nai chahiye", "reason": "nai lena"}, {"remark": "mara order nhi hy", "reason": "mara order nhi hy"}, {"remark": "return kr den ye hum ne nai lena", "reason": "return kt den"}, {"remark": "bhai hum ne koi order nai kiya", "reason": "no order"}, {"remark": "Refuse", "reason": "Refuse"}, {"remark": "parcel ka sun kar call cut kar di", "reason": "parcel ka sun kar call cut kar di"}, {"remark": "wapis kr den ye man cancel kr diya tha", "reason": "Refuse"}, {"remark": "Bht din pehly order kiya tha ab nai lena", "reason": "late aya hai"}, {"remark": "Number off hai", "reason": "whats app pr b no reply"}, {"remark": "ni lana", "reason": "refuse"}, {"remark": "mera koi order nai hai", "reason": "wapis kr den"}, {"remark": "mara order nhi ihy", "reason": "refuse"}, {"remark": "mara order nhi ihy", "reason": "Refuse"}, {"remark": "abi hum ghr nai han jb ayen gy to call kar den gy", "reason": "refuse"}, {"remark": "Not Intersted", "reason": "refuse"}, {"remark": "Pehly b kaha tha k nai lena", "reason": "refuse"}, {"remark": "call nhi attend ki", "reason": "refuse"}, {"remark": "jis ne order kiya tha wo chala gya hai", "reason": "nai lena"}, {"remark": "Double Order Ho Gaya Tha", "reason": "Double Order Ho Gaya Tha"}, {"remark": "hum ne koi order nai kiya", "reason": "refuse"}, {"remark": "man ne kuch order nai kiya", "reason": "nai lena"}, {"remark": "nai lena wapis kr den", "reason": "cancelled"}, {"remark": "jab lana huwa call kar dy gy", "reason": "Refuse"}, {"remark": "Gaon aa k dy k jao", "reason": "refuse"}, {"remark": "hum ne ye cancel kr diya tha", "reason": "wapis kr den"}, {"remark": "hum ne ye cancel kr diya tha", "reason": "refuse"}, {"remark": "Mera Order Nahi Hai", "reason": "refuse"}, {"remark": "call ni attend ki", "reason": "refuse"}], "Out Of Service Area": [{"remark": "Gaoun aa k dy k jao", "reason": "NSA"}, {"remark": "Gaoun aa k dy k jao", "reason": "Already receive"}, {"remark": "Rider ko btaya tha k nai chahiye", "reason": "refuse"}, {"remark": "NON SERVICE AREA", "reason": "refuse"}, {"remark": "NSA Area", "reason": "NSA Area"}, {"remark": "Gaoun main aa k dy k jao", "reason": "NSA"}, {"remark": "bhai hum ne koi order nai kiya", "reason": "no order"}, {"remark": "jab lana huwa call kar dy gy", "reason": "Refuse"}, {"remark": "Rider ko btaya tha k nai chahiye", "reason": "nai lena"}, {"remark": "out of city ho return kar do", "reason": "refuse"}, {"remark": "Gaoun main aa k dy k jao", "reason": "NSA Area"}], "No Such Order From Consignee": [{"remark": "return kr den ye hum ne nai lena", "reason": "return kt den"}, {"remark": "abi hum ghr nai han jb ayen gy to call kar den gy", "reason": "refuse"}, {"remark": "man ne koi order nai kiya", "reason": "nai lena"}, {"remark": "galti sy order ho gya tha", "reason": "wapis kr den"}, {"remark": "mera koi order nai hai", "reason": "nai lena"}, {"remark": "nai lena wapis kr den", "reason": "nai lena"}, {"remark": "nai lena rider ko b bataya tha", "reason": "nai lena"}, {"remark": "wapis kr den ye man cancel kr diya tha", "reason": "refuse"}, {"remark": "Pehly b kaha tha k nai lena", "reason": "nai lena"}, {"remark": "Rider ko btaya tha k nai chahiye", "reason": "refuse"}, {"remark": "ye hum ne usi wqt cancel kr diya tha", "reason": "refuse"}, {"remark": "hum ne nai lena wapis kr den", "reason": "nai lena"}, {"remark": "man ne ye refuse kr diya tha", "reason": "refuse"}, {"remark": "wapis kr den ye man cancel kr diya tha", "reason": "Refuse"}, {"remark": "ghr nai hun ap wapis kr den", "reason": "refuse"}, {"remark": "hum ne nai lena wapis kr den", "reason": "refuse"}, {"remark": "man ne ye refuse kr diya tha", "reason": "nai lena"}, {"remark": "rider ko bataya tha k nai lena", "reason": "refuse"}, {"remark": "my yaha nhi ho", "reason": "Consignee Unavailable"}, {"remark": "Pehly b kaha tha k nai lena", "reason": "refuse"}, {"remark": "rider ko bataya tha k nai lena", "reason": "nai lena"}, {"remark": "bad my btata ho", "reason": "refuse"}, {"remark": "ye man ne pehly he refuse kr diya tha", "reason": "wapis kr den"}, {"remark": "man ne koi order nai kiya", "reason": "refuse"}, {"remark": "nai lena wapis kr den", "reason": "wapis kr den"}, {"remark": "nhi lana", "reason": "Quality Issue"}, {"remark": "return kr den ye hum ne nai lena", "reason": "nai lena"}, {"remark": "nhi lana", "reason": "nhi lana"}, {"remark": "out of city ho return kar do", "reason": "refuse"}, {"remark": "pehly b btaya tha k man ne koi order nai kiya", "reason": "refuse"}, {"remark": "mara order nhi ihy", "reason": "wapis kr den"}, {"remark": "nai lena rider ko b bataya tha", "reason": "wapis kr den"}, {"remark": "wapis kr den ye man cancel kr diya tha", "reason": "wapis kr den"}, {"remark": "jis ne order kiya tha wo chala gya hai", "reason": "wapis kr den"}, {"remark": "bhai hum ne koi order nai kiya", "reason": "no order"}, {"remark": "man ne koi order nai kiya", "reason": "no order"}, {"remark": "Mera koi order nai hai", "reason": "no order"}, {"remark": "jis ne order kiya tha wo chala gya hai", "reason": "nai lena"}, {"remark": "abi confirm nai kiya tha unho ne bhej diya", "reason": "itni jaldi aa gya"}, {"remark": "rider ly k aya tha tb b cancel kiya tha", "reason": "nai lena"}, {"remark": "ye to man ne cancel kiya tha", "reason": "nai lena"}, {"remark": "Bht din pehly order kiya tha ab nai lena", "reason": "late aya hai"}, {"remark": "Rider ko btaya tha k nai chahiye", "reason": "nai lena"}, {"remark": "jis ne order kiya tha wo chala gya hai", "reason": "refuse"}, {"remark": "ye man ne cancel kr diya tha", "reason": "nai lena"}, {"remark": "ye hum ne cancel kr diya tha", "reason": "nai lena"}, {"remark": "rider b btaya tha k man ne koi order nai kiya", "reason": "refuse"}, {"remark": "rider ko bataya tha k nai lena", "reason": "wapis kr den"}, {"remark": "jab lana huwa again order kar dy gy", "reason": "Refuse"}, {"remark": "ye retun kr den rider ko b kha tha", "reason": "Unavailable"}, {"remark": "Quality Issue", "reason": "Quality Issue"}, {"remark": "man be kuch order nai kiya", "reason": "nai lena"}, {"remark": "Consignee Unavailable", "reason": "Unavailable"}, {"remark": "abi ghr koi b nai hai man aa kr khud lun ga", "reason": "out of city hun"}, {"remark": "galti sy order ho gya tha", "reason": "nai lena"}, {"remark": "Double order ho gya tha", "reason": "Already received"}, {"remark": "Gaon aa k dy k jao", "reason": "refuse"}, {"remark": "open kar ky receive krna hy", "reason": "nai lena"}, {"remark": "ye retun kr den rider ko b kha tha", "reason": "refuse"}, {"remark": "man ne cancel kr diya tha", "reason": "nai lena"}, {"remark": "nai lena wapis kr den", "reason": "refuse"}, {"remark": "man ne bazar sy mangwa liya tha", "reason": "nai lena"}, {"remark": "Rider ko btaya tha k nai chahiye", "reason": "wapis kr den"}, {"remark": "Bht din pehly order kiya tha ab nai lena", "reason": "Late aya hai"}, {"remark": "man ne pehly b btaya tha k nai chahiye", "reason": "nai lena"}, {"remark": "hum ne koi order nai kiya", "reason": "wapis kr den"}, {"remark": "ap isy return kr den hum ne nai lena", "reason": "nai lena"}, {"remark": "hum ne ye cancel kr diya tha", "reason": "refuse"}, {"remark": "bad my btata ho", "reason": "nai lena"}, {"remark": "Nai lena ap ye return kr den", "reason": "wapis kr den"}, {"remark": "ye hum ne pehly he cancel kiya hai", "reason": "nai lena"}, {"remark": "Guest aye thy unho ne order kiya tha", "reason": "oreder nai kiya tha"}, {"remark": "ye hum ne usi wqt cancel kr diya tha", "reason": "cancelled"}, {"remark": "Okara Mein Nahi Ho", "reason": "Refuse"}, {"remark": "nhi lana", "reason": "refuse"}, {"remark": "mara order nhi ihy", "reason": "Refuse"}, {"remark": "man abi out of city hun aoun ga to call karun ga", "reason": "wapis kr den"}, {"remark": "wapis kar do", "reason": "wapis kr den"}, {"remark": "open kar ky receive krna hy", "reason": "Refuse"}, {"remark": "mara order nhi hy", "reason": "refuse"}, {"remark": "jab lana huwa call kar dy gy", "reason": "Refuse"}, {"remark": "Not answring", "reason": "Not answring"}, {"remark": "subha time b bataya tha k nai lena", "reason": "wapis kr den"}, {"remark": "ye hum ne usi wqt cancel kr diya tha", "reason": "nai lena"}, {"remark": "bhai ko puch kr btaoun ga", "reason": "nai lena"}, {"remark": "Mera Order Nahi Hai", "reason": "Mera Order Nahi Hai"}, {"remark": "Rider ko b btaya tha k nai chahiye", "reason": "nai lena"}], "Refused After Opening The Shipment": [{"remark": "Quality Issue", "reason": "Quality Issue"}, {"remark": "Pehly b kaha tha k nai lena", "reason": "refuse"}, {"remark": "mara order nhi ihy", "reason": "wapis kr den"}, {"remark": "pehly b btaya tha k man ne koi order nai kiya", "reason": "refuse"}, {"remark": "jis ne order kiya tha wo chala gya hai", "reason": "nai lena"}], "Delay in Dispatched from Shipper": [{"remark": "Bht din pehly order kiya tha ab nai lena", "reason": "late aya hai"}, {"remark": "Bht din pehly order kiya tha ab nai lena", "reason": "Late aya hai"}, {"remark": "Bht din pehly aya hai", "reason": "Delay in Dispatched from Shipper"}, {"remark": "Bht din pehly order kiya tha ab nai lena", "reason": "Delay in Dispatched from Shipper"}], "Issue In The COD Amount/Product": [{"remark": "Product Issue", "reason": "Product Issue"}, {"remark": "Product issue", "reason": "product issue"}, {"remark": "payment kuch btai thi lkin I kisi or payment par hy", "reason": "nhi lana"}, {"remark": "Amount Issue", "reason": "Amount Issue"}, {"remark": "amount ka issue hy", "reason": "refuse"}, {"remark": "nhi lana price bht zyda hy", "reason": "refuse"}, {"remark": "price bht zyda hy", "reason": "refuse"}, {"remark": "product issue", "reason": "product issue"}], "Duplicate order": [{"remark": "Double Order ho gya tha", "reason": "Already receive"}, {"remark": "Double order ho gya tha", "reason": "Already received"}, {"remark": "Double order ho gya tha", "reason": "Duplicate order"}, {"remark": "Duplicate order", "reason": "Duplicate order"}, {"remark": "hum ne nai lena wapis kr den", "reason": "refuse"}, {"remark": "man ne koi order nai kiya", "reason": "refuse"}, {"remark": "Double Order Ho Gaya Tha", "reason": "Double Order Ho Gaya Tha"}], "Wrong Destination": [{"remark": "Consignee Okara Ka Nahi Hy", "reason": "Consignee Okara Ka Nahi Hy"}, {"remark": "Lahore main lena hai", "reason": "Consignee Okara Ka Nahi Hy"}], "No One Came For Self-Collection": [{"remark": "return kr den ye hum ne nai lena", "reason": "nai lena"}]};

  const savedCache = {}; // trackingNumber -> last saved JSON (to avoid duplicate saves)

  // Directly polls Firebase (not just relying on the background alarm,
  // which can be up to 1 minute behind) so a remote disable takes effect
  // within ~15 seconds, and shows a clear red banner on the page so it's
  // obvious to whoever is using the tracking page (not just in the console).
  const FIREBASE_BASE = "https://sonic-trax-default-rtdb.firebaseio.com";

  function showDisabledBanner(show) {
    let banner = document.getElementById("sonicDisabledBanner");
    if (show) {
      if (banner) return;
      banner = document.createElement("div");
      banner.id = "sonicDisabledBanner";
      banner.textContent = "⛔ Extension Disabled — Please contact admin.";
      banner.style.cssText =
        "position:fixed;top:0;left:0;right:0;z-index:2147483647;background:#c62828;" +
        "color:#fff;text-align:center;padding:10px;font-family:Arial,sans-serif;" +
        "font-weight:bold;font-size:14px;box-shadow:0 2px 8px rgba(0,0,0,0.35);";
      document.documentElement.appendChild(banner);
    } else if (banner) {
      banner.remove();
    }
  }

  function syncRemoteStatus() {
    chrome.storage.local.get({ userId: null }, (data) => {
      if (!data.userId) return; // background.js hasn't registered this device yet
      Promise.all([
        fetch(`${FIREBASE_BASE}/users/${data.userId}/enabled.json`, { cache: "no-store" }).then((r) => r.json()),
        fetch(`${FIREBASE_BASE}/serverStatus/enabled.json`, { cache: "no-store" }).then((r) => r.json())
      ])
        .then(([userVal, serverVal]) => {
          const serverEnabled = serverVal === null ? true : serverVal === true; // default ON if unset
          const effective = userVal === true && serverEnabled;
          chrome.storage.local.set({ adminEnabled: effective });
          showDisabledBanner(!effective);
        })
        .catch(() => {}); // offline / network hiccup - keep last known state
    });
  }

  syncRemoteStatus();
  setInterval(syncRemoteStatus, 15000);

  // "Extension context invalidated" shows up when the extension is
  // reloaded/updated from chrome://extensions while this page (the
  // sonic.pk tab) was already open - the old content script becomes
  // "orphaned". There's no code fix for this (it's Chrome's own behavior) -
  // the tab just has to be refreshed. Here we just make sure this error
  // doesn't spam the console repeatedly - we print one clean message and
  // stop all intervals/observers.
  let contextDead = false;
  function isContextAlive() {
    try {
      return !!(chrome && chrome.runtime && chrome.runtime.id);
    } catch (e) {
      return false;
    }
  }
  function killIfContextDead() {
    if (contextDead) return true;
    if (!isContextAlive()) {
      contextDead = true;
      console.log(
        "[Sonic Collector] ⚠️ The extension has been reloaded - this tab's connection is stale. Please REFRESH (F5) this tab once, then everything will work fine again."
      );
      try { observer.disconnect(); } catch (e) {}
      return true;
    }
    return false;
  }

  function normalize(s) {
    if (!s) return "";
    return s.replace(/[\u00A0\s]+/g, " ").trim().replace(/:$/, "");
  }

  function isAfter(marker, el) {
    return !!(marker.compareDocumentPosition(el) & Node.DOCUMENT_POSITION_FOLLOWING);
  }
  function isBefore(marker, el) {
    return !!(marker.compareDocumentPosition(el) & Node.DOCUMENT_POSITION_PRECEDING);
  }

  // Find every element on the whole page whose text (aside from icons etc.)
  // is a valid tracking number (13-16 digits, or the newer 10-digit format). Phone
  // numbers (11 digits) are excluded by this, so they won't accidentally
  // become headers.
  // NOTE: previously only "childless" (leaf) elements were accepted - but
  // Sonic.pk sometimes places an icon alongside the tracking number
  // (e.g. <div>14428965943695 <span><i class="fas fa-box-open"></i></span></div>)
  // which makes the element not a leaf, so it was missed. Now we check
  // textContent (which excludes the icon), and only make sure no child
  // element separately holds the same digits (so parent+child don't
  // accidentally become two separate headers).
  // Tracking-number formats accepted on Sonic.pk:
  //  - 13-16 digits (the usual long format)
  //  - exactly 10 digits (the newer short format, e.g. 6396003844)
  // 11-digit numbers (phone numbers with leading 0) are still excluded. A
  // 10-digit number starting with 3 is also skipped, because that is how a
  // Pakistani mobile number looks without the leading 0 (3XX XXXXXXX).
  // Also, if the number was typed into the tracking input box, it is always
  // accepted (10-16 digits) - whatever format it has.
  function isTrackingNumberText(txt) {
    if (/^\d{13,16}$/.test(txt)) return true;
    if (/^\d{10}$/.test(txt)) {
      let list = [];
      try { list = getTrackingInputList(); } catch (e) {}
      // A list was typed in: a 10-digit number counts ONLY if it is in that
      // list (so random 10-digit numbers elsewhere on the page can't
      // become fake headers and break the data scoping).
      if (list.length) return list.includes(txt);
      // No list (page opened directly): accept, except mobile-like (3...).
      return !/^3/.test(txt);
    }
    return false;
  }

  function findTrackingHeaders() {
    const headers = [];
    const all = document.querySelectorAll("body *");
    for (const el of all) {
      const txt = normalize(el.textContent);
      if (!isTrackingNumberText(txt)) continue;
      let hasMatchingChild = false;
      for (const child of el.children) {
        if (isTrackingNumberText(normalize(child.textContent))) {
          hasMatchingChild = true;
          break;
        }
      }
      if (hasMatchingChild) continue;
      // A short (10-digit) number can be repeated in other places on the
      // page (details section etc.) - only the FIRST occurrence is the
      // header, otherwise the parcel's data gets cut in half.
      if (txt.length === 10 && headers.some((h) => normalize(h.textContent) === txt)) continue;
      headers.push(el);
    }
    return headers;
  }

  // Look for the label (like "Name", "Origin") only between startMarker and
  // endMarker - so that data from different parcels doesn't get mixed up.
  function getValueByLabelScoped(label, startMarker, endMarker) {
    const target = normalize(label).toLowerCase();
    const all = document.querySelectorAll("body *");
    for (const el of all) {
      if (el.children.length !== 0) continue;
      if (startMarker && !isAfter(startMarker, el)) continue;
      if (endMarker && !isBefore(endMarker, el)) continue;
      const txt = normalize(el.textContent).toLowerCase();
      if (txt !== target) continue;

      let sib = el.nextElementSibling;
      if (sib && normalize(sib.textContent)) return normalize(sib.textContent);

      const parent = el.parentElement;
      if (parent) {
        const parentSib = parent.nextElementSibling;
        if (parentSib && normalize(parentSib.textContent)) return normalize(parentSib.textContent);

        const row = parent.closest("tr") || parent.parentElement;
        if (row) {
          const cells = Array.from(row.children);
          for (const c of cells) {
            if (c.contains(el)) continue;
            const t = normalize(c.textContent);
            if (t) return t;
          }
        }
      }
    }
    return "";
  }

  // Only these reasons/remarks are allowed (from the Bolt app's "Why you
  // could not deliver" list). If anything other than these appears in the
  // reason or remarks column, it won't be picked up (left blank).
  const KNOWN_REASONS = [
    "Consignee Out Of City",
    "Wrong Destination",
    "Out Of Service Area",
    "Consignee Wants To Open The Shipment",
    "Issue In The COD Amount/Product",
    "No Such Order From Consignee",
    "Refused After Opening The Shipment",
    "Delay in Dispatched from Shipper",
    "Delay in Delivery From TRAX",
    "Duplicate order",
    "Purchased From Outlet",
    "Quality Issue",
    "Change of Mind",
    "Place another order",
    "Other"
  ];
  const KNOWN_REASONS_LOWER = KNOWN_REASONS.map((r) => r.toLowerCase());

  // When a rider writes their own free text (doesn't match the fixed
  // list), we give that text a rough category based on keywords.
  // Priority order top to bottom - whichever matches first is used.
  function classifyFreeTextReason(text) {
    const t = (text || "").toLowerCase();
    if (t.includes("cancel")) return "Cancelled";
    if (t.includes("nai lena") || t.includes("nahi lena") || t.includes("nai chahiye") || t.includes("nahi chahiye")) return "Nai Lena";
    if (t.includes("wapis") || t.includes("return") || t.includes("retun")) return "Wapis Kar Den";
    if (t.includes("refuse")) return "Refuse";
    return ""; // leave blank if no keyword matches - don't write "Different"
  }

  // Checks the reason/remarks text against the whitelist. If there's no
  // exact match, checks whether a known reason is hidden inside the text
  // (sometimes an extra label/punctuation comes along with it). Returns
  // an empty string if nothing matches - meaning that cell isn't picked up.
  function matchKnownReason(text) {
    if (!text) return "";
    const t = normalize(text).toLowerCase();
    const exactIdx = KNOWN_REASONS_LOWER.indexOf(t);
    if (exactIdx !== -1) return KNOWN_REASONS[exactIdx];
    for (let i = 0; i < KNOWN_REASONS_LOWER.length; i++) {
      if (t.includes(KNOWN_REASONS_LOWER[i])) return KNOWN_REASONS[i];
    }
    return "";
  }

  // If the current status consists only of numbers (e.g. some ID/code
  // accidentally ends up in that column), don't pick it up.
  function isNumericOnly(s) {
    if (!s) return false;
    return /^\d+$/.test(normalize(s));
  }

  // Sonic.pk's status/reason cells are often followed by a "case/reference
  // number" in parentheses, e.g. "Shipment - Reason Validation Required
  // (3806538)". Since textContent grabs the whole cell at once, this
  // number used to get attached to the status text. Here we strip that
  // trailing "(digits)" part off so only the real status/reason text
  // remains.
  function stripTrailingCode(s) {
    const t = normalize(s);
    if (!t) return "";
    return t.replace(/\s*\(\s*\d{3,}\s*\)\s*$/, "").trim();
  }

  // Pulls a Pakistani mobile number (e.g. 03001234567, +923001234567,
  // 0300-1234567) out of a larger piece of text - used both for a
  // dedicated rider-number column and as a fallback when the number is
  // written alongside the rider's name in the same cell.
  function extractPhoneNumber(s) {
    const t = normalize(s);
    if (!t) return "";
    const match = t.match(/(?:\+?92|0)[\s-]?3\d{2}[\s-]?\d{7}/);
    if (!match) return "";
    // Normalize to plain digits with a leading 0 (e.g. "03001234567").
    let digits = match[0].replace(/[\s-]/g, "");
    if (digits.startsWith("+92")) digits = "0" + digits.slice(3);
    else if (digits.startsWith("92")) digits = "0" + digits.slice(2);
    return digits;
  }

  function getTrackingHistoryInfoScoped(startMarker, endMarker) {
    const tables = document.querySelectorAll("table");
    for (const table of tables) {
      if (startMarker && !isAfter(startMarker, table)) continue;
      if (endMarker && !isBefore(endMarker, table)) continue;

      const headerCells = table.querySelectorAll(
        "thead th, thead td, tr:first-child th, tr:first-child td"
      );
      const headers = Array.from(headerCells).map((c) => normalize(c.textContent).toLowerCase());
      const statusIdx = headers.findIndex((h) => h.includes("status"));
      const reasonIdx = headers.findIndex((h) => h.includes("reason"));
      const remarksIdx = headers.findIndex((h) => h.includes("remark"));
      const riderIdx = headers.findIndex((h) => h.includes("rider"));
      // Dedicated rider phone/contact column, if the site has a separate
      // one (e.g. "Rider Contact", "Rider Mobile", "Rider Number").
      const riderNumberIdx = headers.findIndex(
        (h) => h.includes("rider") && (h.includes("contact") || h.includes("mobile") || h.includes("phone") || h.includes("number"))
      );

      if (statusIdx !== -1) {
        const bodyRows = table.querySelectorAll("tbody tr");
        const rows = bodyRows.length ? bodyRows : Array.from(table.querySelectorAll("tr")).slice(1);

        let currentStatus = "";
        let riderStatus = "";
        let riderStatusFallback = ""; // real text, kept instead of leaving blank when nothing matches the whitelist
        let attemptCount = 0;
        let riderName = "";
        let riderNumber = "";

        rows.forEach((row, idx) => {
          const cells = row.querySelectorAll("td");
          if (!cells.length) return;
          const statusText = cells[statusIdx] ? stripTrailingCode(cells[statusIdx].textContent) : "";
          const reasonText = reasonIdx !== -1 && cells[reasonIdx] ? stripTrailingCode(cells[reasonIdx].textContent) : "";
          const remarksText = remarksIdx !== -1 && cells[remarksIdx] ? stripTrailingCode(cells[remarksIdx].textContent) : "";
          const riderText = riderIdx !== -1 && cells[riderIdx] ? normalize(cells[riderIdx].textContent) : "";
          const riderNumberText = riderNumberIdx !== -1 && cells[riderNumberIdx] ? normalize(cells[riderNumberIdx].textContent) : "";

          if (idx === 0) {
            currentStatus = isNumericOnly(statusText) ? "" : statusText;
          }
          // Rows are ordered top-to-bottom from latest to oldest. Wherever
          // (whether idx 0 or an older row below) the reason/remarks match
          // the whitelist, take the very first (i.e. latest) match - ignore
          // any older matches that come after it.
          if (!riderStatus) {
            riderStatus = matchKnownReason(reasonText) || matchKnownReason(remarksText);
          }
          // If nothing matches the whitelist (new/different wording), still
          // don't leave it blank - keep the first (latest) row's actual
          // reason/remarks text as a fallback.
          if (!riderStatusFallback) {
            riderStatusFallback = reasonText || remarksText;
          }
          if (/out for delivery/i.test(statusText)) attemptCount++;
          // The very first (topmost / most recent) row that has a Rider
          // name is the currently assigned rider.
          if (!riderName && riderText) riderName = riderText;
          if (!riderNumber) {
            if (riderNumberText) {
              riderNumber = extractPhoneNumber(riderNumberText) || riderNumberText;
            } else if (riderText) {
              // No dedicated number column - the phone number is sometimes
              // written right alongside the rider's name in the same cell
              // (e.g. "Ali Khan (03001234567)").
              riderNumber = extractPhoneNumber(riderText);
            }
          }
        });

        if (!riderStatus) riderStatus = riderStatusFallback;

        // If the current status says "shipment on hold", automatically set
        // the rider status to "Hold On Consignee Request" (the
        // reason/remarks column is often empty in this case, so we
        // override it).
        if (/on\s*hold/i.test(currentStatus)) {
          riderStatus = "Hold On Consignee Request";
        }

        if (currentStatus) return { currentStatus, riderStatus, attemptCount, riderName, riderNumber, riderStatusFallback };
      }
    }
    return { currentStatus: "", riderStatus: "", attemptCount: 0, riderName: "", riderNumber: "", riderStatusFallback: "" };
  }

  // Pulls out the data for however many parcel results are on the page (be
  // it 1 or a bulk 20) into a single array.
  function scanAllRecords() {
    const headers = findTrackingHeaders();
    const records = [];
    for (let i = 0; i < headers.length; i++) {
      const startMarker = headers[i];
      const endMarker = headers[i + 1] || null;
      const trackingNumber = normalize(headers[i].textContent);
      const shipperName = getValueByLabelScoped("Name", startMarker, endMarker);
      const origin = getValueByLabelScoped("Origin", startMarker, endMarker);
      const segment = getValueByLabelScoped("Sub Segment", startMarker, endMarker);
      const { currentStatus, riderStatus, attemptCount, riderName, riderNumber, riderStatusFallback } = getTrackingHistoryInfoScoped(startMarker, endMarker);
      records.push({ trackingNumber, shipperName, origin, segment, riderName, riderNumber, currentStatus, riderStatus, attemptCount, riderStatusFallback });
    }
    return records;
  }

  // Manual debug: for testing yourself in the console
  window.__sonicDebugScan = () => {
    const r = scanAllRecords();
    console.log("[Sonic Collector] MANUAL SCAN ->", r);
    return r;
  };

  // Plays a pleasant "ding-ding" notification chime when a new parcel is
  // collected (two notes, rising slightly) - much softer and more
  // pleasant-sounding than a plain sine beep.
  function playBeep() {
    chrome.storage.local.get({ soundEnabled: true }, (data) => {
      if (data.soundEnabled === false) return;
      try {
        const ctx = new (window.AudioContext || window.webkitAudioContext)();
        const masterGain = ctx.createGain();
        masterGain.gain.value = 0.35;
        masterGain.connect(ctx.destination);

        // Two notes: first slightly lower, second slightly higher (major
        // third jump) - gives a "success chime" feel.
        const notes = [
          { freq: 987.77, start: 0.0, dur: 0.16 },   // B5
          { freq: 1318.51, start: 0.1, dur: 0.32 }   // E6
        ];

        notes.forEach(({ freq, start, dur }) => {
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.type = "sine";
          osc.frequency.value = freq;

          // Add a small harmonic overtone to make the sound a bit more "bell-like"
          const overtone = ctx.createOscillator();
          const overtoneGain = ctx.createGain();
          overtone.type = "sine";
          overtone.frequency.value = freq * 2;
          overtoneGain.gain.value = 0.12;

          osc.connect(gain);
          overtone.connect(overtoneGain);
          overtoneGain.connect(gain);
          gain.connect(masterGain);

          const t0 = ctx.currentTime + start;
          gain.gain.setValueAtTime(0, t0);
          gain.gain.linearRampToValueAtTime(0.9, t0 + 0.015); // fast attack
          gain.gain.exponentialRampToValueAtTime(0.001, t0 + dur); // smooth decay

          osc.start(t0);
          overtone.start(t0);
          osc.stop(t0 + dur + 0.05);
          overtone.stop(t0 + dur + 0.05);
        });

        setTimeout(() => ctx.close(), 700);
      } catch (e) {
        console.log("[Sonic Collector] beep failed to play:", e);
      }
    });
  }

  // BUG FIX: previously every attempt() ran its own separate
  // chrome.storage.local.get()+set(). When many attempts run in quick
  // succession (mutation observer + the 1.5s poll, firing several times at
  // once for bulk (31) parcels), a "race condition" formed between their
  // get() and set(): two attempts would read the same stale parcels list,
  // each would add its own new records to that stale list, and whichever
  // saved last would completely overwrite the earlier save - which is why
  // only 1-2 out of 31 scanned parcels ended up saved. Fix: all saves now
  // go through a single queue (chain) so that every save always happens
  // against the FRESHEST (latest) storage state, and no save overwrites
  // another.
  let storageQueue = Promise.resolve();

  function saveRecordsBatch(toSave) {
    storageQueue = storageQueue.then(
      () =>
        new Promise((resolve) => {
          chrome.storage.local.get({ parcels: [] }, (data) => {
            const parcels = data.parcels || [];
            let newCount = 0;

            toSave.forEach(({ r, isNew }) => {
                // "Reason" and "DBF Remarks" - these are 2 new columns.
              // For a Rider Status we have real historical examples for
              // (from past DBF reports), randomly pick one of those real
              // (remark, reason) pairs - so the auto-filled text varies and
              // looks like an authentic manual entry each time, instead of
              // always writing the exact same fixed phrase.
              const riderStatus = r.riderStatus || "";
              let reason = riderStatus;
              let dbfRemarks = "";

              if (riderStatus === "Refused After Opening The Shipment") {
                // Always fixed - not random.
                reason = "Quality Issue";
                dbfRemarks = "Quality Issue";
              } else if (riderStatus === "Hold On Consignee Request") {
                // Always fixed - not random.
                reason = "Consignee Unavailable";
                dbfRemarks = "Consignee Unavailable";
              } else if (riderStatus === "Out Of Service Area") {
                // Always fixed - not random.
                reason = "Door Step par deliver kary";
                dbfRemarks = "Door Step par deliver kary";
              } else {
                const historyPairs = RIDER_STATUS_HISTORY[riderStatus];
                if (historyPairs && historyPairs.length) {
                  const pick = historyPairs[Math.floor(Math.random() * historyPairs.length)];
                  reason = pick.reason;
                  dbfRemarks = pick.remark;
                } else if (riderStatus === "Consignee Out Of City") {
                  // No historical examples for this one - keep the fixed fallback.
                  reason = "Refuse";
                  dbfRemarks = "Okara Mein Nahi Ho";
                } else if (riderStatus && !KNOWN_REASONS.includes(riderStatus)) {
                  // riderStatus didn't match the site's fixed reason list and
                  // we have no history for it either - meaning the rider
                  // wrote their own brand-new free text. Apply a rough
                  // category through keywords - if no keyword matches, it
                  // stays blank.
                  reason = classifyFreeTextReason(riderStatus);
                  dbfRemarks = reason;
                }
              }

              const record = {
                trackingNumber: r.trackingNumber,
                segment: r.segment || "",
                shipperName: r.shipperName || "",
                origin: r.origin || "",
                currentStatus: r.currentStatus || "",
                actualAttempt: r.attemptCount,
                riderStatus: riderStatus,
                reason: reason,
                dbfRemarks: dbfRemarks,
                riderName: r.riderName || "",
                riderNumber: r.riderNumber || "",
                capturedAt: new Date().toISOString()
              };
              const existingIdx = parcels.findIndex((p) => p.trackingNumber === record.trackingNumber);
              if (existingIdx !== -1) parcels[existingIdx] = record;
              else parcels.push(record);
              if (isNew) newCount++;
            });

            chrome.storage.local.set({ parcels }, () => {
              console.log("[Sonic Collector] SAVED OK (" + toSave.length + " parcel(s) this time). Total so far:", parcels.length);
              if (newCount > 0) playBeep();

              // Let the admin panel show this device's parcel count + last-seen time.
              chrome.storage.local.get({ userId: null }, (d) => {
                if (!d.userId) return;
                fetch(`${FIREBASE_BASE}/users/${d.userId}.json`, {
                  method: "PATCH",
                  headers: { "Content-Type": "application/json" },
                  body: JSON.stringify({ parcelCount: parcels.length, lastSeen: Date.now() })
                }).catch(() => {});
              });

              resolve();
            });
          });
        })
    ).catch((e) => {
      console.log("[Sonic Collector] save queue error:", e);
    });
  }

  // BUG FIX: sometimes MORE records than the input list got saved (e.g. 20
  // entered, 21 came out). Reason: findTrackingHeaders() treats every small
  // element on the page whose text is 13-16 digits as a "tracking number" -
  // if a similar digit pattern happens to appear elsewhere on the page (an
  // old search, sidebar, some other ID), or it's a leftover record from a
  // previous session, it accidentally becomes a "phantom" parcel. Fix:
  // whenever the user clicks Track, the IDs typed in at that moment become
  // the "current session expected list" - only tracking numbers in this
  // list will be saved during this session. (currentSessionExpected stays
  // null until a Track click happens - so that if the page is opened
  // directly, whatever is found there also gets captured.)
  let currentSessionExpected = null;
  let sessionCompleteLogged = false;

  // BUG FIX: sometimes 1 tracking number's data got saved
  // INCOMPLETE/WRONG (e.g. only the status came through, shipper/origin/
  // rider stayed blank) - because there's a race between the scan and the
  // DOM render: the card hadn't fully loaded yet when it got scanned, and
  // that incomplete data got saved as "final".
  // Fix: now a record only gets saved once it's seen EXACTLY THE SAME
  // (stable) across TWO CONSECUTIVE scans - meaning the render has
  // settled. If the data changes between two consecutive attempts (still
  // rendering), the save is held back to wait for the next attempt.
  const warnedIncomplete = {};
  const pendingStable = {}; // trackingNumber -> last-seen serialized (not yet confirmed stable)

  function attempt(tag) {
    if (killIfContextDead()) return;
    chrome.storage.local.get({ adminEnabled: false, localEnabled: true }, (data) => {
      if (data.adminEnabled === false || data.localEnabled === false) return;

      attemptNum++;

      const records = scanAllRecords();

      if (attemptNum % 5 === 1) {
        console.log("[Sonic Collector] " + tag + " #" + attemptNum + " -> found " + records.length + " parcel(s)", records);
      }

      // First gather all new/changed records, then save them all AT ONCE
      // (saving them separately used to cause data to get overwritten due
      // to a "race condition")
      const toSave = [];
      records.forEach((r) => {
        // Status is always required (the dashboard's whole purpose is
        // showing status) - so currentStatus being present is now
        // MANDATORY, along with at least one of Name or Origin.
        const gotEnoughData = r.trackingNumber && !!r.currentStatus && (r.shipperName || r.origin);
        if (!gotEnoughData) {
          if (currentSessionExpected && currentSessionExpected.has(r.trackingNumber) && !warnedIncomplete[r.trackingNumber]) {
            warnedIncomplete[r.trackingNumber] = true;
            console.log("[Sonic Collector] ⚠️ " + r.trackingNumber + " found, but data is incomplete (needs Status + Name/Origin) - NOT saved yet:", JSON.stringify(r));
          }
          return;
        }

        // If this session's expected list exists and this number isn't in
        // it, treat it as a phantom/leftover and DO NOT save it - just
        // flag it in the console so it's visible.
        if (currentSessionExpected && !currentSessionExpected.has(r.trackingNumber)) {
          return;
        }

        const serialized = JSON.stringify(r);
        if (savedCache[r.trackingNumber] === serialized) return; // no change, don't save again

        // If the record's data is already COMPLETE (Name + Origin +
        // Status, all three present), save it IMMEDIATELY - don't wait for
        // the next scan. The stability-wait is only left for records whose
        // data is still incomplete (some field is empty) - since that's
        // the case where the page might still be rendering.
        const isFullyComplete = !!(r.shipperName && r.origin && r.currentStatus);

        if (!isFullyComplete) {
          // Stability check: does the data seen for this number in the
          // previous attempt match this one exactly? If not (or this is
          // the first time it's appeared), don't save yet - just note it
          // as "pending" and wait for the next scan so the render can
          // settle.
          if (pendingStable[r.trackingNumber] !== serialized) {
            pendingStable[r.trackingNumber] = serialized;
            return;
          }
        }

        const isNew = !(r.trackingNumber in savedCache);
        savedCache[r.trackingNumber] = serialized;
        toSave.push({ r, isNew });
      });

      // The diagnostic only runs once (about 51s after the Track click) and
      // reports whatever is missing at that time - but after that, the
      // background poll keeps running and more parcels may still be found,
      // with no confirmation of this (causing confusion about "are these
      // still missing or did they arrive?"). Now, whenever all of a
      // session's expected parcels have been saved, a single clear
      // "✅ ALL RECEIVED" message prints once.
      if (currentSessionExpected && currentSessionExpected.size > 0 && !sessionCompleteLogged) {
        const gotCount = Array.from(currentSessionExpected).filter((tn) => tn in savedCache).length;
        if (gotCount >= currentSessionExpected.size) {
          sessionCompleteLogged = true;
          console.log("[Sonic Collector] ✅ All " + currentSessionExpected.size + " parcels were found and saved! You can check the dashboard.");
        }
      }

      if (toSave.length > 0) saveRecordsBatch(toSave);
    });
  }

  console.log("[Sonic Collector] content script started on this page:", window.location.href);

  // When the Track button is clicked - wait based on how many tracking
  // numbers were entered (more parcels = longer wait, so the site has time
  // to fully render all the data), then do one reliable/solid capture.
  // This doesn't depend on scrolling at all - Sonic.pk puts all the data
  // into the DOM, it just takes a bit of time.
  function getTrackingInputList() {
    const input = document.querySelector('input[name="tracking_numbers"], textarea[name="tracking_numbers"]');
    const val = input && input.value ? input.value.trim() : "";
    if (!val) return [];
    return val.split(/[,\n\s]+/).map((id) => id.trim()).filter((id) => id !== "");
  }

  function getTrackingInputCount() {
    const list = getTrackingInputList();
    return list.length || 1;
  }

  // Out of however many tracking numbers were entered, this clearly lists
  // in the console which ones haven't shown up on the page (in the scan)
  // yet - so it's clear whether the problem is with the extension (the
  // number is in the DOM but wasn't captured) or with sonic.pk itself (the
  // number hasn't loaded on the page yet / turned out duplicate / turned
  // out invalid).
  function logMissingNumbers(inputList) {
    if (!inputList.length) return;
    const foundSet = new Set(scanAllRecords().map((r) => r.trackingNumber));
    const uniqueInput = Array.from(new Set(inputList));
    const missing = uniqueInput.filter((id) => !foundSet.has(id));
    if (missing.length) {
      console.log(
        "[Sonic Collector] " + missing.length + " tracking number(s) NOT found on the page yet:",
        missing
      );
    } else {
      console.log("[Sonic Collector] All entered tracking numbers were found (duplicates, if any, are counted only once).");
    }
  }

  // Auto-scroll capture: Sonic.pk doesn't put some parcels (the ones at the
  // end of the list) into the DOM until the page is scrolled (lazy /
  // virtual list). Scrolling was removed before because scrolling would
  // unload older cards and lose their data - but NOW every "complete"
  // record is saved immediately (see attempt() above), so there's no
  // downside to unloading via scroll - whatever was already found will
  // already have been saved. Now we scroll down in small steps, pausing
  // briefly and scanning after each step, so that the last parcels in the
  // list also get rendered and captured.
  function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  async function autoScrollCapture() {
    // Scrolling has been removed - now we just pause and scan a few times
    // without scrolling the page. NOTE: the parcels on Sonic.pk that only
    // lazy-load on scroll (the last ones in the list) won't be captured
    // this way - only whatever loads into the DOM on its own without
    // scrolling will be captured.
    const rounds = 3;
    const pauseMs = 1300;

    for (let i = 0; i < rounds; i++) {
      if (killIfContextDead()) return;
      await sleep(pauseMs);
      attempt("no-scroll-try");
    }
  }

  function calculateWaitTime(idCount) {
    // Base wait of 20 seconds + a bit extra for bulk (15+ IDs) - so the
    // page has more time to fully render all parcels and more data comes
    // out "complete" on the very first scan, which now gets saved
    // immediately (see isFullyComplete above).
    // NOTE: the background capture (MutationObserver + the 1.5s poll) is
    // completely independent of this wait and always keeps running as
    // long as the tab is open.
    if (idCount > 15) return 25000;
    return 20000;
  }

  document.addEventListener("click", (e) => {
    if (killIfContextDead()) return;
    const target = e.target;
    const looksLikeTrackBtn =
      target.matches && target.matches('button, input[type="submit"]') &&
      ((target.textContent || "").toLowerCase().includes("track") ||
        (target.value || "").toLowerCase().includes("track"));
    if (!looksLikeTrackBtn) return;

    const inputList = getTrackingInputList();
    const idCount = inputList.length || 1;
    const waitTime = calculateWaitTime(idCount);

    // Set the "expected" list for this session - from now on only these
    // tracking numbers will be saved, until the next Track click.
    currentSessionExpected = inputList.length ? new Set(inputList) : null;
    sessionCompleteLogged = false;

    console.log("[Sonic Collector] Track button clicked - " + idCount + " ID(s), doing a " + (waitTime / 1000) + "s dynamic wait, then will also auto-scroll...");

    setTimeout(async () => {
      attempt("post-track-click");
      await autoScrollCapture();
      let foundSoFar = scanAllRecords().length;
      if (foundSoFar >= idCount) {
        logMissingNumbers(inputList);
        return;
      }

      console.log("[Sonic Collector] Only found " + foundSoFar + "/" + idCount + " - will scroll+scan again in 10s...");
      setTimeout(async () => {
        attempt("post-track-retry-1");
        await autoScrollCapture();
        foundSoFar = scanAllRecords().length;
        if (foundSoFar >= idCount) {
          logMissingNumbers(inputList);
          return;
        }
        console.log("[Sonic Collector] Still only " + foundSoFar + "/" + idCount + " - waiting 10s more for a final diagnostic check...");
        setTimeout(async () => {
          attempt("post-track-retry-2");
          await autoScrollCapture();
          logMissingNumbers(inputList);
        }, 10000);
      }, 10000);
    }, waitTime);
  });

  // 1) try immediately
  attempt("try");

  // 2) if the DOM changes, wait a bit and try again - so mid-render
  //    (incomplete) data isn't captured, and scanning only happens once
  //    the DOM has settled
  let debounceTimer = null;
  const observer = new MutationObserver(() => {
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(() => attempt("mutation-try"), 500);
  });
  observer.observe(document.body, { childList: true, subtree: true });
})();
