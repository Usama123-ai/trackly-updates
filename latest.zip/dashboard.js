function escapeHtml(str) {
  if (str === undefined || str === null) return "";
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

let knownTrackingNumbers = new Set();
let isFirstLoad = true;
let allParcels = [];
let searchQuery = "";

function matchesSearch(p, q) {
  if (!q) return true;
  const haystack = [
    p.trackingNumber, p.segment, p.shipperName, p.origin,
    p.currentStatus, p.riderStatus, p.dbfRemarks, p.reason, p.riderName, p.riderNumber
  ].map((v) => String(v === undefined || v === null ? "" : v).toLowerCase()).join(" | ");
  return haystack.includes(q);
}

function renderTable() {
  const tbody = document.getElementById("tableBody");
  const countEl = document.getElementById("count");
  const noResults = document.getElementById("noResults");
  const q = searchQuery.trim().toLowerCase();

  const filtered = allParcels.filter((p) => matchesSearch(p, q));

  const prevCount = countEl.textContent;
  countEl.textContent = q ? `${filtered.length} / ${allParcels.length}` : String(allParcels.length);
  if (!isFirstLoad && String(prevCount) !== String(countEl.textContent)) {
    countEl.classList.remove("bump");
    void countEl.offsetWidth;
    countEl.classList.add("bump");
  }

  tbody.innerHTML = "";
  noResults.style.display = (q && filtered.length === 0) ? "block" : "none";

  filtered.forEach((p) => {
    const tr = document.createElement("tr");
    const isNewRow = !isFirstLoad && !knownTrackingNumbers.has(p.trackingNumber);
    if (isNewRow) tr.classList.add("new-row");
    tr.innerHTML = `
      <td>${escapeHtml(p.trackingNumber)}</td>
      <td><span class="badge">${escapeHtml(p.segment)}</span></td>
      <td>${escapeHtml(p.shipperName)}</td>
      <td>${escapeHtml(p.origin)}</td>
      <td>${escapeHtml(p.currentStatus)}</td>
      <td>${escapeHtml(String(p.actualAttempt))}</td>
      <td>${escapeHtml(p.riderStatus)}</td>
      <td>${escapeHtml(p.dbfRemarks)}</td>
      <td>${escapeHtml(p.reason)}</td>
      <td>${escapeHtml(p.riderName)}</td>
      <td>${escapeHtml(p.riderNumber)}</td>
    `;
    tbody.appendChild(tr);
  });

  knownTrackingNumbers = new Set(allParcels.map((p) => p.trackingNumber));
  isFirstLoad = false;
}

function loadParcels() {
  chrome.storage.local.get({ parcels: [] }, (data) => {
    allParcels = data.parcels || [];
    renderTable();
  });
}

function setupSearch() {
  const input = document.getElementById("searchBox");
  const clearBtn = document.getElementById("searchClearBtn");

  input.addEventListener("input", () => {
    searchQuery = input.value;
    clearBtn.classList.toggle("show", searchQuery.length > 0);
    renderTable();
  });

  clearBtn.addEventListener("click", () => {
    input.value = "";
    searchQuery = "";
    clearBtn.classList.remove("show");
    renderTable();
    input.focus();
  });
}

// Shows a click ripple effect on every button
function addRippleEffect(btn) {
  btn.addEventListener("click", (e) => {
    const rect = btn.getBoundingClientRect();
    const ripple = document.createElement("span");
    const size = Math.max(rect.width, rect.height) * 1.2;
    ripple.className = "ripple";
    ripple.style.width = ripple.style.height = size + "px";
    ripple.style.left = (e.clientX - rect.left - size / 2) + "px";
    ripple.style.top = (e.clientY - rect.top - size / 2) + "px";
    btn.appendChild(ripple);
    setTimeout(() => ripple.remove(), 550);
  });
}

function playOnceAnim(el, className, duration) {
  el.classList.remove(className);
  void el.offsetWidth;
  el.classList.add(className);
  setTimeout(() => el.classList.remove(className), duration);
}

document.querySelectorAll("button").forEach(addRippleEffect);

// Real .xlsx export (SheetJS) - this used to be plain CSV, which showed
// encoding/format warnings when opened in Excel and had no styling.
// Now it builds a real Excel workbook: columns auto-fit their width based
// on the data, and the sheet is named after today's date.
const HEADERS = ["Tracking Number", "Segment", "Shipper Name", "Origin", "Current Status", "Actual Attempt", "Rider Status", "DBF Remarks", "Reason", "Rider Name", "Rider Number"];
const FIELD_KEYS = ["trackingNumber", "segment", "shipperName", "origin", "currentStatus", "actualAttempt", "riderStatus", "dbfRemarks", "reason", "riderName", "riderNumber"];

function computeColumnWidths(parcels) {
  return HEADERS.map((h, i) => {
    const key = FIELD_KEYS[i];
    let max = h.length;
    parcels.forEach((p) => {
      const len = String(p[key] === undefined || p[key] === null ? "" : p[key]).length;
      if (len > max) max = len;
    });
    return { wch: Math.min(Math.max(max + 2, 10), 40) };
  });
}

function exportToXlsx() {
  const exportBtn = document.getElementById("exportBtn");

  if (typeof XLSX === "undefined") {
    alert("The Excel library failed to load. Please reload the extension.");
    return;
  }

  chrome.storage.local.get({ parcels: [] }, (data) => {
    const all = data.parcels || [];
    const q = searchQuery.trim().toLowerCase();
    const parcels = q ? all.filter((p) => matchesSearch(p, q)) : all;
    if (!parcels.length) {
      playOnceAnim(exportBtn, "shake", 450);
      alert("No data has been collected yet.");
      return;
    }

    const rows = parcels.map((p) => {
      const row = {};
      HEADERS.forEach((h, i) => { row[h] = p[FIELD_KEYS[i]] === undefined || p[FIELD_KEYS[i]] === null ? "" : p[FIELD_KEYS[i]]; });
      return row;
    });

    // NOTE: the free/community build of SheetJS doesn't support cell-level
    // styling (bold/colored headers) - so only data + column widths are set
    // here. The real .xlsx format (formulas, filters, cross-app
    // compatibility) still works fine, the header row just won't be colored.
    const worksheet = XLSX.utils.json_to_sheet(rows, { header: HEADERS });
    worksheet["!cols"] = computeColumnWidths(parcels);
    worksheet["!autofilter"] = { ref: worksheet["!ref"] };

    const workbook = XLSX.utils.book_new();
    const sheetName = "Parcels " + new Date().toISOString().slice(0, 10);
    XLSX.utils.book_append_sheet(workbook, worksheet, sheetName);

    const filename = "sonic_parcels_" + new Date().toISOString().slice(0, 10) + ".xlsx";
    XLSX.writeFile(workbook, filename);

    const origText = exportBtn.textContent;
    exportBtn.textContent = "✓ Exported!";
    playOnceAnim(exportBtn, "success", 600);
    setTimeout(() => { exportBtn.textContent = origText; }, 1400);
  });
}

function clearAll() {
  const clearBtn = document.getElementById("clearBtn");
  if (confirm("Are you sure you want to delete all collected data?")) {
    chrome.storage.local.set({ parcels: [] }, loadParcels);
  } else {
    playOnceAnim(clearBtn, "shake", 450);
  }
}

function setupSoundToggle() {
  const btn = document.getElementById("soundBtn");

  function render(soundEnabled) {
    if (soundEnabled) {
      btn.textContent = "🔊 Sound On";
      btn.classList.add("sound-on");
    } else {
      btn.textContent = "🔇 Sound Off";
      btn.classList.remove("sound-on");
    }
  }

  chrome.storage.local.get({ soundEnabled: true }, (data) => {
    render(data.soundEnabled);
  });

  btn.addEventListener("click", () => {
    chrome.storage.local.get({ soundEnabled: true }, (data) => {
      const newVal = !data.soundEnabled;
      chrome.storage.local.set({ soundEnabled: newVal }, () => {
        render(newVal);
        playOnceAnim(btn, "toggle-pop", 400);
      });
    });
  });
}

function setupThemeToggle() {
  const btn = document.getElementById("themeBtn");
  const body = document.body;

  function render(mode) {
    if (mode === "light") {
      body.classList.remove("theme-dark");
      body.classList.add("theme-light");
      btn.textContent = "☀️ Light";
    } else {
      body.classList.remove("theme-light");
      body.classList.add("theme-dark");
      btn.textContent = "🌙 Dark";
    }
  }

  chrome.storage.local.get({ themeMode: "dark" }, (data) => {
    render(data.themeMode);
  });

  btn.addEventListener("click", () => {
    chrome.storage.local.get({ themeMode: "dark" }, (data) => {
      const newMode = data.themeMode === "dark" ? "light" : "dark";
      chrome.storage.local.set({ themeMode: newMode }, () => {
        render(newMode);
        playOnceAnim(btn, "spin", 500);
      });
    });
  });
}

document.getElementById("exportBtn").addEventListener("click", exportToXlsx);
document.getElementById("clearBtn").addEventListener("click", clearAll);
setupSoundToggle();
setupThemeToggle();
setupSearch();

// Top-left corner: Google profile photo + Gmail (or first letter + ID for
// normal ID accounts). All of this is read from this browser only.
function renderAccount() {
  chrome.storage.local.get({ accountUser: null, accountEmail: null, accountName: null, accountPicture: null }, (d) => {
    const chip = document.getElementById("acctChip");
    if (!chip) return;
    const img = document.getElementById("brandAvatarImg");
    const letter = document.getElementById("brandAvatarLetter");
    const sub = document.getElementById("brandSub");
    const label = d.accountEmail || d.accountUser || "";

    document.getElementById("acctText").textContent = label;
    chip.title = d.accountName ? d.accountName + " · " + label : label;
    chip.style.display = label ? "inline-flex" : "none";
    if (sub) sub.style.display = label ? "none" : "";

    letter.textContent = String(d.accountName || label || "L").trim().charAt(0).toUpperCase() || "L";
    const showLetter = () => { img.style.display = "none"; letter.style.display = "flex"; };
    if (d.accountPicture) {
      img.onload = () => { img.style.display = "block"; letter.style.display = "none"; };
      img.onerror = showLetter;
      img.src = d.accountPicture;
    } else {
      img.removeAttribute("src");
      showLetter();
    }
  });
}

function showLoggedIn() {
  document.getElementById("loginScreen").style.display = "none";
  document.getElementById("mainApp").style.display = "block";
  renderAccount();
  loadParcels();
}

function showLoggedOut() {
  document.getElementById("loginScreen").style.display = "flex";
  document.getElementById("mainApp").style.display = "none";
}

// Remote kill-switch: checks Firebase directly (rather than only the
// locally-synced flag, which can be up to a minute behind) so that a
// remote disable blocks the dashboard almost immediately - the user sees
// a clear "contact admin" screen instead of the data. Each device has its
// own entry under /users/<userId>, so the admin can control every
// registered device individually from the phone.
const FIREBASE_BASE = "https://sonic-trax-default-rtdb.firebaseio.com";

function checkRemoteStatus(cb) {
  chrome.storage.local.get({ userId: null }, (data) => {
    if (!data.userId) { cb(false); return; } // not registered yet - stay blocked
    Promise.all([
      fetch(`${FIREBASE_BASE}/users/${data.userId}/enabled.json`, { cache: "no-store" }).then((r) => r.json()),
      fetch(`${FIREBASE_BASE}/serverStatus/enabled.json`, { cache: "no-store" }).then((r) => r.json())
    ])
      .then(([userVal, serverVal]) => {
        const serverEnabled = serverVal === null ? true : serverVal === true; // default ON if unset
        cb(userVal === true && serverEnabled); // only an explicit true (admin-approved) + server ON counts as enabled
      })
      .catch(() => cb(true)); // offline - fail open rather than locking out on a network hiccup
  });
}

function showBlockedScreen() {
  document.getElementById("loginScreen").style.display = "none";
  document.getElementById("mainApp").style.display = "none";
  document.getElementById("blockedScreen").style.display = "flex";
}

function isBlockedScreenVisible() {
  return document.getElementById("blockedScreen").style.display !== "none";
}

function runLoginFlow() {
  sonicCheckLogin((loggedIn) => {
    if (loggedIn) showLoggedIn();
    else showLoggedOut();
  });
}

function startAccessGate() {
  checkRemoteStatus((enabled) => {
    if (!enabled) {
      showBlockedScreen();
    } else {
      document.getElementById("blockedScreen").style.display = "none";
      runLoginFlow();
    }
  });

  // Keep re-checking while the dashboard stays open, so a remote disable
  // (or re-enable) mid-session takes effect without needing a reload.
  setInterval(() => {
    checkRemoteStatus((enabled) => {
      if (!enabled) {
        showBlockedScreen();
      } else if (isBlockedScreenVisible()) {
        runLoginFlow();
      }
    });
  }, 15000);
}

document.getElementById("loginSubmitBtn").addEventListener("click", () => {
  const id = document.getElementById("loginId").value.trim();
  const pass = document.getElementById("loginPass").value.trim();
  sonicAttemptLogin(id, pass, (ok) => {
    if (ok) {
      document.getElementById("loginError").textContent = "";
      showLoggedIn();
    } else {
      document.getElementById("loginError").textContent = "Incorrect ID or password.";
      playOnceAnim(document.querySelector(".login-card"), "shake", 450);
    }
  });
});

document.getElementById("loginPass").addEventListener("keydown", (e) => {
  if (e.key === "Enter") document.getElementById("loginSubmitBtn").click();
});

document.getElementById("logoutBtn").addEventListener("click", () => {
  sonicLogout(() => {
    document.getElementById("loginId").value = "";
    document.getElementById("loginPass").value = "";
    showLoggedOut();
  });
});

// Forgot password: shows the reset-with-keyword panel (built in auth.js).
function setupForgotPassword() {
  const forgotLink = document.getElementById("forgotPasswordLink");
  const backLink = document.getElementById("backToLoginLink");
  const recoveryPanel = document.getElementById("recoveryPanel");
  const loginFields = [
    document.getElementById("loginId"),
    document.getElementById("loginPass"),
    document.getElementById("loginSubmitBtn")
  ];
  forgotLink.addEventListener("click", (e) => {
    e.preventDefault();
    loginFields.forEach((el) => { el.style.display = "none"; });
    document.getElementById("loginError").textContent = "";
    forgotLink.style.display = "none";
    recoveryPanel.style.display = "block";
  });
  backLink.addEventListener("click", (e) => {
    e.preventDefault();
    loginFields.forEach((el) => { el.style.display = ""; });
    forgotLink.style.display = "";
    recoveryPanel.style.display = "none";
  });
}

setupForgotPassword();

startAccessGate();

// ---------- Admin notification banner ----------
function renderNotifBanner(data) {
  const el = document.getElementById("adminNotifBanner");
  const expired = data && data.expiresAt && Date.now() > data.expiresAt;
  if (data && data.message && !expired) {
    el.textContent = "📢 " + data.message;
    el.style.display = "block";
  } else {
    el.style.display = "none";
  }
}

function checkNotifBanner() {
  fetch(`${FIREBASE_BASE}/notification.json`, { cache: "no-store" })
    .then((r) => r.json())
    .then((data) => renderNotifBanner(data))
    .catch(() => {}); // leave banner as-is on a network hiccup
}

checkNotifBanner();
setInterval(checkNotifBanner, 15000);

// Keeps the dashboard live-updating even while it stays open - whether a
// new parcel gets collected or "Clear All" wipes the data, the table
// refreshes immediately in both cases without needing to reopen the dashboard.
chrome.storage.onChanged.addListener((changes, namespace) => {
  if (namespace === "local" && changes.parcels) {
    loadParcels();
  }
});

// ---------- Parcel Count — Smart Assistant ----------
// Note: this runs entirely on-device (no external AI API call). Shipping a
// real AI API key inside a browser extension isn't safe - anyone can
// unzip/inspect the extension files and steal it - so instead this uses
// rule-based text parsing to pull tracking numbers + judge delivered vs
// undelivered from status keywords. It covers the exact use case asked for
// (give it data, get back the undelivered tracking numbers) without that risk.

function isDeliveredStatus(text) {
  const t = (text || "").toLowerCase();
  if (!t) return false;
  const negated = /\b(not|un|non|no)[\s-]*delivered\b/.test(t) || /\bfail(ed)?\s*delivery\b/.test(t);
  if (negated) return false;
  return /\bdelivered\b/.test(t) || /\bpod\b/.test(t) || /\bsuccessful(ly)?\s*delivered\b/.test(t);
}

function getCollectedUndelivered() {
  return allParcels.filter((p) => !isDeliveredStatus(p.currentStatus)).map((p) => p.trackingNumber);
}

// Pulls tracking numbers (9-20 digit sequences) out of any pasted text and
// classifies each one as delivered/undelivered - a tracking number that
// shows "Delivered" on ANY of its lines is counted as delivered (that's
// the final state), everything else counts as undelivered.
function analyzeText(text) {
  const trackingRegex = /\b\d{9,20}\b/g;
  const lines = (text || "").split(/\r?\n/);
  const statusByTracking = new Map(); // trackingNumber -> true (delivered) | false (undelivered so far)

  lines.forEach((line) => {
    const matches = line.match(trackingRegex);
    if (!matches) return;
    const delivered = isDeliveredStatus(line);
    matches.forEach((tn) => {
      const prev = statusByTracking.get(tn);
      if (prev === true) return; // already confirmed delivered elsewhere - keep it
      statusByTracking.set(tn, delivered);
    });
  });

  const all = Array.from(statusByTracking.keys());
  const undeliveredList = all.filter((tn) => statusByTracking.get(tn) !== true);
  const deliveredList = all.filter((tn) => statusByTracking.get(tn) === true);

  return { total: all.length, delivered: deliveredList.length, deliveredList, undeliveredList };
}

function setParcelCountStats(total, delivered, undelivered) {
  document.getElementById("pcTotal").textContent = total;
  document.getElementById("pcDelivered").textContent = delivered;
  document.getElementById("pcUndelivered").textContent = undelivered;
}

function refreshParcelCountStats() {
  const total = allParcels.length;
  const delivered = allParcels.filter((p) => isDeliveredStatus(p.currentStatus)).length;
  setParcelCountStats(total, delivered, total - delivered);
}

function showPcResult(list) {
  const wrap = document.getElementById("pcResultWrap");
  const box = document.getElementById("pcResultBox");
  const countEl = document.getElementById("pcResultCount");
  wrap.style.display = "block";
  countEl.textContent = list.length;
  box.value = list.length ? list.join("\n") : "None found.";
}

document.getElementById("parcelCountBtn").addEventListener("click", () => {
  refreshParcelCountStats();
  document.getElementById("pcResultWrap").style.display = "none";
  document.getElementById("pcPasteBox").value = "";
  document.getElementById("emailResultWrap").style.display = "none";
  document.getElementById("emailTrackingInput").value = "";
  document.getElementById("emailRecipientInput").value = "";
  document.getElementById("emailSenderInput").value = "";
  document.getElementById("emailSenderCompanyInput").value = "";
  document.getElementById("emailPointsBox").value = "";
  document.getElementById("parcelCountOverlay").style.display = "flex";
});

document.getElementById("parcelCountCloseBtn").addEventListener("click", () => {
  document.getElementById("parcelCountOverlay").style.display = "none";
});

document.getElementById("parcelCountOverlay").addEventListener("click", (e) => {
  if (e.target.id === "parcelCountOverlay") {
    document.getElementById("parcelCountOverlay").style.display = "none";
  }
});

document.getElementById("pcListCollectedBtn").addEventListener("click", () => {
  refreshParcelCountStats();
  showPcResult(getCollectedUndelivered());
});

document.getElementById("pcExtractUndeliveredBtn").addEventListener("click", () => {
  const text = document.getElementById("pcPasteBox").value;
  if (!text.trim()) {
    alert("Paste some data first.");
    return;
  }
  const { total, delivered, undeliveredList } = analyzeText(text);
  setParcelCountStats(total, delivered, undeliveredList.length);
  showPcResult(undeliveredList);
});

document.getElementById("pcExtractDeliveredBtn").addEventListener("click", () => {
  const text = document.getElementById("pcPasteBox").value;
  if (!text.trim()) {
    alert("Paste some data first.");
    return;
  }
  const { total, delivered, deliveredList, undeliveredList } = analyzeText(text);
  setParcelCountStats(total, delivered, undeliveredList.length);
  showPcResult(deliveredList);
});

// Clears the result + pasted data (and resets counts to the collected data)
// so a fresh batch can be entered right away.
document.getElementById("pcClearBtn").addEventListener("click", () => {
  document.getElementById("pcResultBox").value = "";
  document.getElementById("pcResultCount").textContent = "0";
  document.getElementById("pcResultWrap").style.display = "none";
  const pasteBox = document.getElementById("pcPasteBox");
  pasteBox.value = "";
  refreshParcelCountStats();
  pasteBox.focus();
});

document.getElementById("pcCopyBtn").addEventListener("click", () => {
  const box = document.getElementById("pcResultBox");
  box.select();
  navigator.clipboard.writeText(box.value).then(() => {
    const btn = document.getElementById("pcCopyBtn");
    const original = btn.textContent;
    btn.textContent = "✓ Copied";
    setTimeout(() => { btn.textContent = original; }, 1200);
  }).catch(() => {});
});

// ---------- Email Writer ----------
// Template-based (no external AI call, for the same on-device/safety reasons
// as the Smart Assistant above): pick a reason, fill in the points, and this
// assembles a short, professional English email with a subject line.

const EMAIL_TEMPLATES = {
  status_update: {
    subject: (tn) => `Status Update Request${tn ? " – Tracking " + tn : ""}`,
    opening: "I hope this email finds you well. I am writing to request an update on the current status of the shipment mentioned below.",
    closing: "Could you please confirm the current status and expected delivery timeline at your earliest convenience?"
  },
  undelivered_complaint: {
    subject: (tn) => `Parcel Not Delivered${tn ? " – Tracking " + tn : ""}`,
    opening: "I am writing to bring to your attention that the parcel mentioned below has still not been delivered.",
    closing: "I would appreciate it if you could look into this matter urgently and arrange delivery as soon as possible."
  },
  delay_complaint: {
    subject: (tn) => `Delivery Delay${tn ? " – Tracking " + tn : ""}`,
    opening: "I would like to report a delay in the delivery of the shipment mentioned below.",
    closing: "Kindly investigate the delay and let me know the revised delivery timeline."
  },
  wrong_status: {
    subject: (tn) => `Incorrect Status Reported${tn ? " – Tracking " + tn : ""}`,
    opening: "I am writing to report that the status shown for the shipment below does not match the actual situation.",
    closing: "Please review and correct the status at your earliest convenience."
  },
  reschedule: {
    subject: (tn) => `Delivery Reschedule Request${tn ? " – Tracking " + tn : ""}`,
    opening: "I would like to request a reschedule of the delivery for the shipment mentioned below.",
    closing: "Please let me know a suitable new delivery date and time."
  },
  general: {
    subject: () => `Inquiry Regarding Parcel Delivery`,
    opening: "I am writing regarding the following matter.",
    closing: "I would appreciate your response at your earliest convenience."
  },
  custom: {
    subject: (tn) => `Regarding Parcel Delivery${tn ? " – Tracking " + tn : ""}`,
    opening: "",
    closing: "Thank you for your attention to this matter."
  }
};

function generateEmailContent() {
  const reason = document.getElementById("emailReasonSelect").value;
  const trackingRaw = document.getElementById("emailTrackingInput").value.trim();
  const recipient = document.getElementById("emailRecipientInput").value.trim();
  const sender = document.getElementById("emailSenderInput").value.trim();
  const senderCompany = document.getElementById("emailSenderCompanyInput").value.trim();
  const pointsRaw = document.getElementById("emailPointsBox").value.trim();

  const tpl = EMAIL_TEMPLATES[reason] || EMAIL_TEMPLATES.general;
  const trackingList = trackingRaw ? trackingRaw.split(",").map((s) => s.trim()).filter(Boolean) : [];
  const tnLabel = trackingList.join(", ");

  const subject = tpl.subject(tnLabel);
  const greeting = recipient ? `Dear ${recipient},` : "Dear Sir/Madam,";
  const points = pointsRaw ? pointsRaw.split(/\r?\n/).map((l) => l.trim()).filter(Boolean) : [];

  const bodyLines = [greeting, ""];
  if (tpl.opening) bodyLines.push(tpl.opening);
  if (tnLabel) bodyLines.push(`Tracking Number(s): ${tnLabel}`);
  if (points.length) {
    if (bodyLines[bodyLines.length - 1] !== "") bodyLines.push("");
    bodyLines.push("Details:");
    points.forEach((p) => bodyLines.push(`- ${p}`));
  }
  bodyLines.push("", tpl.closing, "", "Thank you.", "", "Best regards,", sender || "[Your Name]");
  if (senderCompany) bodyLines.push(senderCompany);

  return { subject, body: bodyLines.join("\n") };
}

document.getElementById("emailGenerateBtn").addEventListener("click", () => {
  const reason = document.getElementById("emailReasonSelect").value;
  const pointsRaw = document.getElementById("emailPointsBox").value.trim();
  if (!pointsRaw && reason === "custom") {
    alert("Please add at least one point for a custom email.");
    return;
  }
  const { subject, body } = generateEmailContent();
  document.getElementById("emailSubjectBox").value = subject;
  document.getElementById("emailBodyBox").value = body;
  document.getElementById("emailResultWrap").style.display = "block";
});

document.getElementById("emailCopySubjectBtn").addEventListener("click", () => {
  const box = document.getElementById("emailSubjectBox");
  if (!box.value) return;
  box.select();
  navigator.clipboard.writeText(box.value).then(() => {
    const btn = document.getElementById("emailCopySubjectBtn");
    const original = btn.textContent;
    btn.textContent = "✓";
    setTimeout(() => { btn.textContent = original; }, 1200);
  }).catch(() => {});
});

document.getElementById("emailCopyBodyBtn").addEventListener("click", () => {
  const bodyBox = document.getElementById("emailBodyBox");
  const subjectBox = document.getElementById("emailSubjectBox");
  if (!bodyBox.value) return;
  const fullText = `Subject: ${subjectBox.value}\n\n${bodyBox.value}`;
  navigator.clipboard.writeText(fullText).then(() => {
    const btn = document.getElementById("emailCopyBodyBtn");
    const original = btn.textContent;
    btn.textContent = "✓ Copied";
    setTimeout(() => { btn.textContent = original; }, 1200);
  }).catch(() => {});
});
