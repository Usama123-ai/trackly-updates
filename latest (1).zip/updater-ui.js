// updater-ui.js - "Update now" bar + "Check for updates" link on the dashboard.
(function () {
  const bar = document.getElementById("updateBar");
  const msg = document.getElementById("updateMsg");
  const btn = document.getElementById("updateBtn");
  const link = document.getElementById("checkUpdateLink");
  const result = document.getElementById("checkResult");
  const verNum = document.getElementById("verNum");
  const current = chrome.runtime.getManifest().version;
  if (verNum) verNum.textContent = current;

  let lastInfo = null;
  let dismissed = false;
  function render(info) {
    lastInfo = info;
    if (dismissed) { bar.style.display = "none"; return; }
    if (tracklyUpdateAvailable(info, current)) {
      msg.textContent = "🔄 New version available: v" + info.version + (info.notes ? " — " + info.notes : "");
      bar.style.display = "flex";
    } else {
      bar.style.display = "none";
    }
  }

  chrome.storage.local.get({ updateInfo: null }, (d) => render(d.updateInfo));
  tracklyCheckForUpdate(true).then(render);
  chrome.storage.onChanged.addListener((c, ns) => { if (ns === "local" && c.updateInfo) render(c.updateInfo.newValue); });

  const closeBtn = document.getElementById("updateCloseBtn");
  if (closeBtn) closeBtn.addEventListener("click", () => { dismissed = true; bar.style.display = "none"; });
  const manual = document.getElementById("manualUpdateLink");
  function showManual(on) { if (manual) manual.style.display = on ? "inline" : "none"; }

  function friendly(e) {
    const m = e && e.message;
    const n = e && e.name;
    if (n === "AbortError") return "Folder window was closed. Click Update now and select the Trackly folder again - or use \"Download update manually\".";
    if (n === "SecurityError" || n === "NotAllowedError") return "The browser blocked the folder access. Click Update now again and press 'Edit files' - or use 'Download update manually'.";
    if (m === "WRONG_FOLDER") return "That is not the Trackly extension folder. Choose the folder that contains manifest.json.";
    if (m === "NO_UPDATE") return "Already on the latest version.";
    if (m === "HASH_MISMATCH") return "Download not ready yet (GitHub is still refreshing). Wait 5 minutes and try again.";
    if (m === "DOWNLOAD_FAILED") return "Could not download the update. Check your internet and try again.";
    if (m === "BAD_ZIP") return "The update file is not valid. Please tell the admin.";
    if (m === "WRITE_FAILED") return "Could not write " + (e.detail || "a file") + ". Close other programs using the folder, or use 'Download update manually'.";
    return "Update failed: " + (n ? n + " - " : "") + (m || e);
  }

  btn.addEventListener("click", async () => {
    btn.disabled = true;
    showManual(false);
    try {
      await tracklyApplyUpdate((t) => { msg.textContent = t; });
    } catch (e) {
      msg.textContent = friendly(e);
      btn.disabled = false;
      if (!(e && e.message === "NO_UPDATE")) showManual(true);
      setTimeout(() => { if (!btn.disabled) render(lastInfo); }, 10000);
    }
  });

  if (manual) manual.addEventListener("click", async (ev) => {
    ev.preventDefault();
    try {
      const v = await tracklyDownloadUpdateZip((t) => { msg.textContent = t; });
      msg.textContent = "Downloaded Trackly-v" + v + ".zip. Unzip it into your Trackly folder (replace files), then open chrome://extensions and press Reload on Trackly.";
    } catch (e) {
      msg.textContent = friendly(e);
    }
  });

  link.addEventListener("click", async (ev) => {
    ev.preventDefault();
    result.textContent = "Checking...";
    const info = await tracklyCheckForUpdate(true);
    render(info);
    result.textContent = tracklyUpdateAvailable(info, current) ? "Update found!" : "You are up to date.";
    setTimeout(() => { result.textContent = ""; }, 4000);
  });
})();
